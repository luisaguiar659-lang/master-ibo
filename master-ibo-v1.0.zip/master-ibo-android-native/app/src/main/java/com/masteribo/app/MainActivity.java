package com.masteribo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String BASE = "https://gerenciaapp.top/";
    private static final String DASHBOARD = "https://gerenciaapp.top/dashboard";
    private static final String USERS = "https://gerenciaapp.top/users";
    private static final String CREATE_USER = "https://gerenciaapp.top/users/create";

    private static final Set<String> ALLOWED_HOSTS = new HashSet<>(Arrays.asList(
            "gerenciaapp.top",
            "www.gerenciaapp.top"
    ));

    private enum Flow {
        ACTIVATE,
        EDIT_M3U
    }

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private ScrollView consoleView;
    private LinearLayout progressList;
    private LinearLayout loginScreen;
    private LinearLayout appScreen;

    private TextView loginStatus;
    private TextView connectionStatus;
    private TextView appLabel;
    private TextView serverLabel;

    private EditText emailInput;
    private EditText passwordInput;
    private EditText macInput;
    private EditText serverInput;
    private EditText playlistInput;

    private Spinner flowSpinner;
    private Spinner appSpinner;

    private Button executeButton;
    private Button panelButton;
    private Button summaryButton;
    private Button logoutButton;
    private Button loginButton;

    private SharedPreferences securePrefs;

    private Flow activeFlow = Flow.ACTIVATE;

    private boolean authenticated = false;
    private boolean running = false;
    private boolean loginOnlyMode = false;
    private boolean loginInjected = false;
    private boolean automationInjected = false;
    private boolean searchInjected = false;
    private int loginRetryCount = 0;
    private int automationRetryCount = 0;

    private String currentMac = "";
    private String currentPlaylist = "";
    private String currentServer = "";
    private String currentApp = "";

    private final String[] apps = new String[]{
            "Selecione um aplicativo",
            "FACILITA",
            "Gerencia Max",
            "GPC PRO ANDROID",
            "IBO REVENDA",
            "IBONEW",
            "TV ROKU - GPC PRO",
            "UNI REVENDA",
            "VU REVENDA",
            "ZONE X"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        securePrefs = createSecurePreferences();
        buildUi();
        setupWebView();
        loadSavedCredentials();

        showLoginScreen();

        if (!emailInput.getText().toString().trim().isEmpty()
                && !passwordInput.getText().toString().isEmpty()) {
            loginStatus.setText("Entrando automaticamente...");
            authenticateOnly();
        }
    }

    private SharedPreferences createSecurePreferences() {
        try {
            MasterKey key = new MasterKey.Builder(this)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            return EncryptedSharedPreferences.create(
                    this,
                    "master_ibo_secure",
                    key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception error) {
            throw new RuntimeException("Falha ao inicializar armazenamento seguro.", error);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(
                settings.getUserAgentString() + " MasterIBO/1.0"
        );

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AutomationBridge(), "AutomationBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request
            ) {
                String host = request.getUrl().getHost();

                if (host == null || !ALLOWED_HOSTS.contains(host)) {
                    toast("Navegação externa bloqueada.");
                    return true;
                }

                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                handlePageFinished(url);
            }
        });
    }

    private void buildUi() {
        int pad = dp(16);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(pad, dp(14), pad, dp(10));

        TextView title = new TextView(this);
        title.setText("MASTER IBO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setTypeface(null, 1);
        title.setLetterSpacing(0.02f);

        topBar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        panelButton = topButton("PAINEL");
        panelButton.setOnClickListener(v -> togglePanel());
        topBar.addView(panelButton);

        summaryButton = topButton("RESUMO");
        summaryButton.setOnClickListener(v -> showSummary());
        topBar.addView(summaryButton);

        logoutButton = topButton("SAIR");
        logoutButton.setOnClickListener(v -> logout());
        topBar.addView(logoutButton);

        root.addView(topBar);

        View glowLine = new View(this);
        glowLine.setBackgroundResource(getDrawableId("bg_glow_line", "drawable"));
        root.addView(glowLine, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(3)
        ));

        // LOGIN
        loginScreen = new LinearLayout(this);
        loginScreen.setOrientation(LinearLayout.VERTICAL);
        loginScreen.setPadding(dp(22), dp(28), dp(22), dp(40));

        ImageView loginLogo = new ImageView(this);
        loginLogo.setImageResource(getDrawableId("logo_master_ibo", "drawable"));
        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(dp(170), dp(170));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        loginLogo.setLayoutParams(logoParams);
        loginScreen.addView(loginLogo);

        loginScreen.addView(space());

        TextView loginTitle = new TextView(this);
        loginTitle.setText("MASTER IBO");
        loginTitle.setTextColor(Color.WHITE);
        loginTitle.setTextSize(28);
        loginTitle.setTypeface(null, 1);
        loginTitle.setGravity(Gravity.CENTER_HORIZONTAL);
        loginScreen.addView(loginTitle);

        TextView loginSubtitle = new TextView(this);
        loginSubtitle.setText("Entre para acessar a automação IBO.");
        loginSubtitle.setTextColor(Color.rgb(168, 179, 188));
        loginSubtitle.setTextSize(14);
        loginSubtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        loginSubtitle.setPadding(0, dp(8), 0, dp(28));
        loginScreen.addView(loginSubtitle);

        emailInput = field("E-mail", false);
        passwordInput = field("Senha", true);

        loginScreen.addView(emailInput);
        loginScreen.addView(space());
        loginScreen.addView(passwordInput);
        loginScreen.addView(space());

        loginButton = new Button(this);
        loginButton.setText("ENTRAR");
        loginButton.setTextSize(15);
        loginButton.setTypeface(null, 1);
        loginButton.setTextColor(Color.WHITE);
        loginButton.setBackgroundResource(getDrawableId("bg_login_gradient", "drawable"));
        loginButton.setOnClickListener(v -> authenticateOnly());
        loginScreen.addView(loginButton, matchHeight(dp(56)));

        loginStatus = new TextView(this);
        loginStatus.setText("");
        loginStatus.setTextColor(Color.rgb(0, 184, 255));
        loginStatus.setTextSize(13);
        loginStatus.setPadding(0, dp(18), 0, 0);
        loginScreen.addView(loginStatus);

        root.addView(
                loginScreen,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        // APP
        appScreen = new LinearLayout(this);
        appScreen.setOrientation(LinearLayout.VERTICAL);
        appScreen.setVisibility(View.GONE);

        consoleView = new ScrollView(this);
        consoleView.setFillViewport(true);

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(20), dp(18), dp(40));

        LinearLayout brandCard = new LinearLayout(this);
        brandCard.setOrientation(LinearLayout.HORIZONTAL);
        brandCard.setGravity(Gravity.CENTER_VERTICAL);
        brandCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        brandCard.setBackgroundResource(getDrawableId("bg_card", "drawable"));

        ImageView miniLogo = new ImageView(this);
        miniLogo.setImageResource(getDrawableId("logo_master_ibo", "drawable"));
        brandCard.addView(miniLogo, new LinearLayout.LayoutParams(dp(68), dp(68)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(12), 0, 0, 0);

        TextView brandName = new TextView(this);
        brandName.setText("MASTER IBO");
        brandName.setTextColor(Color.WHITE);
        brandName.setTextSize(19);
        brandName.setTypeface(null, 1);

        connectionStatus = new TextView(this);
        connectionStatus.setText("● Conectado");
        connectionStatus.setTextColor(Color.rgb(0, 184, 255));
        connectionStatus.setTextSize(12);

        brandText.addView(brandName);
        brandText.addView(connectionStatus);

        brandCard.addView(
                brandText,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        form.addView(brandCard);
        form.addView(sectionGap());
        form.addView(sectionTitle("PAINEL DE AUTOMAÇÃO"));

        flowSpinner = new Spinner(this);
        ArrayAdapter<String> flowAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{
                        "Ativar MAC + M3U",
                        "Editar / Repor M3U"
                }
        );
        flowSpinner.setAdapter(flowAdapter);
        flowSpinner.setBackgroundResource(getDrawableId("bg_input", "drawable"));
        form.addView(flowSpinner, matchHeight(dp(56)));

        form.addView(space());

        macInput = field("MAC do dispositivo", false);
        form.addView(macInput);

        form.addView(space());

        appLabel = sectionFieldLabel("APLICATIVO DO CLIENTE");
        form.addView(appLabel);

        appSpinner = new Spinner(this);
        ArrayAdapter<String> appAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                apps
        );
        appSpinner.setAdapter(appAdapter);
        appSpinner.setBackgroundResource(getDrawableId("bg_input", "drawable"));
        form.addView(appSpinner, matchHeight(dp(56)));

        form.addView(space());

        serverLabel = sectionFieldLabel("NOME DO SERVIDOR");
        form.addView(serverLabel);

        serverInput = field("Nome do servidor", false);
        serverInput.setText("Meu aplicativo");
        form.addView(serverInput);

        form.addView(space());

        playlistInput = field("URL M3U", false);
        playlistInput.setMinLines(2);
        playlistInput.setGravity(Gravity.TOP);
        form.addView(playlistInput);

        form.addView(space());

        executeButton = new Button(this);
        executeButton.setText("EXECUTAR");
        executeButton.setTextSize(15);
        executeButton.setTypeface(null, 1);
        executeButton.setTextColor(Color.WHITE);
        executeButton.setBackgroundResource(getDrawableId("bg_action_gradient", "drawable"));
        executeButton.setOnClickListener(v -> startFlow());
        form.addView(executeButton, matchHeight(dp(56)));

        form.addView(sectionGap());
        form.addView(sectionTitle("STATUS DA AUTOMAÇÃO"));

        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(14), dp(10), dp(14), dp(10));
        statusCard.setBackgroundResource(getDrawableId("bg_card", "drawable"));

        progressList = new LinearLayout(this);
        progressList.setOrientation(LinearLayout.VERTICAL);
        statusCard.addView(progressList);
        form.addView(statusCard);

        addProgress("PRONTO", "Pronto para iniciar.", Color.rgb(136, 148, 139));

        consoleView.addView(form);

        appScreen.addView(
                consoleView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        webView = new WebView(this);
        webView.setVisibility(View.GONE);

        appScreen.addView(
                webView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        root.addView(
                appScreen,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        flowSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(
                    AdapterView<?> parent,
                    View view,
                    int position,
                    long id
            ) {
                boolean activate = position == 0;
                appLabel.setVisibility(activate ? View.VISIBLE : View.GONE);
                appSpinner.setVisibility(activate ? View.VISIBLE : View.GONE);

                if (activate && serverInput.getText().toString().trim().isEmpty()) {
                    serverInput.setText("Meu aplicativo");
                }

                if (!activate) {
                    serverInput.setText("");
                    serverInput.setHint("Nome do servidor (opcional)");
                } else {
                    serverInput.setHint("Nome do servidor");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        setContentView(root);
    }

    private Button topButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(11);
        button.setTextColor(Color.WHITE);
        button.setBackgroundResource(getDrawableId("bg_secondary_button", "drawable"));
        button.setVisibility(View.GONE);
        return button;
    }

    private TextView sectionTitle(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(255, 156, 0));
        view.setTextSize(12);
        view.setTypeface(null, 1);
        view.setLetterSpacing(0.08f);
        view.setPadding(0, 0, 0, dp(12));
        return view;
    }

    private TextView sectionFieldLabel(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(168, 179, 188));
        view.setTextSize(11);
        view.setTypeface(null, 1);
        view.setLetterSpacing(0.06f);
        view.setPadding(0, 0, 0, dp(6));
        return view;
    }

    private EditText field(String hint, boolean password) {
        EditText view = new EditText(this);
        view.setHint(hint);
        view.setHintTextColor(Color.rgb(120, 132, 142));
        view.setTextColor(Color.WHITE);
        view.setTextSize(15);
        view.setPadding(dp(16), dp(14), dp(16), dp(14));
        view.setBackgroundResource(getDrawableId("bg_input", "drawable"));

        if (password) {
            view.setInputType(
                    InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD
            );
        }

        return view;
    }

    private View space() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(12)));
        return v;
    }

    private View sectionGap() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(28)));
        return v;
    }

    private LinearLayout.LayoutParams matchHeight(int height) {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                height
        );
    }

    private void showLoginScreen() {
        authenticated = false;
        loginScreen.setVisibility(View.VISIBLE);
        appScreen.setVisibility(View.GONE);
        panelButton.setVisibility(View.GONE);
        summaryButton.setVisibility(View.GONE);
        logoutButton.setVisibility(View.GONE);
    }

    private void showAppScreen() {
        authenticated = true;
        loginOnlyMode = false;
        running = false;

        loginScreen.setVisibility(View.GONE);
        appScreen.setVisibility(View.VISIBLE);
        consoleView.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);

        panelButton.setVisibility(View.VISIBLE);
        summaryButton.setVisibility(View.VISIBLE);
        logoutButton.setVisibility(View.VISIBLE);

        connectionStatus.setText("● Conectado");
        connectionStatus.setTextColor(Color.rgb(0, 184, 255));

        loginButton.setEnabled(true);
        loginButton.setText("ENTRAR");
        loginStatus.setText("");
        loginRetryCount = 0;
    }

    private void authenticateOnly() {
        if (loginOnlyMode) return;

        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            toast("Informe e-mail e senha.");
            return;
        }

        saveCredentials();

        loginOnlyMode = true;
        running = true;
        authenticated = false;
        loginInjected = false;
        loginRetryCount = 0;

        loginButton.setEnabled(false);
        loginButton.setText("ENTRANDO...");
        loginStatus.setText("Verificando sessão salva...");

        // Primeiro tenta reaproveitar a sessão existente.
        webView.loadUrl(DASHBOARD + "?t=" + System.currentTimeMillis());
    }

    private void logout() {
        running = false;
        authenticated = false;
        loginOnlyMode = false;

        securePrefs.edit()
                .remove("email")
                .remove("password")
                .apply();

        emailInput.setText("");
        passwordInput.setText("");

        webView.clearHistory();
        webView.clearCache(true);

        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();

        connectionStatus.setText("● Desconectado");
        connectionStatus.setTextColor(Color.rgb(136, 148, 139));

        showLoginScreen();
        loginStatus.setText("Sessão encerrada.");
    }

    private void saveCredentials() {
        securePrefs.edit()
                .putString("email", emailInput.getText().toString().trim())
                .putString("password", passwordInput.getText().toString())
                .apply();
    }

    private void loadSavedCredentials() {
        emailInput.setText(securePrefs.getString("email", ""));
        passwordInput.setText(securePrefs.getString("password", ""));
    }

    private void startFlow() {
        if (running) return;

        if (!authenticated) {
            showLoginScreen();
            toast("Faça login primeiro.");
            return;
        }

        String mac = normalizeMac(macInput.getText().toString());
        String playlist = playlistInput.getText().toString().trim();
        String server = serverInput.getText().toString().trim();

        if (!isValidMac(mac)) {
            toast("Informe um MAC válido.");
            return;
        }

        if (!(playlist.startsWith("http://") || playlist.startsWith("https://"))) {
            toast("Informe uma URL M3U válida.");
            return;
        }

        activeFlow = flowSpinner.getSelectedItemPosition() == 1
                ? Flow.EDIT_M3U
                : Flow.ACTIVATE;

        String selectedApp = "";

        if (activeFlow == Flow.ACTIVATE) {
            if (appSpinner.getSelectedItemPosition() <= 0) {
                toast("Selecione o aplicativo do cliente.");
                return;
            }

            selectedApp = String.valueOf(appSpinner.getSelectedItem());

            if (server.isEmpty()) {
                toast("Informe o nome do servidor.");
                return;
            }
        }

        currentMac = mac;
        currentPlaylist = playlist;
        currentServer = server;
        currentApp = selectedApp;

        automationInjected = false;
        searchInjected = false;
        automationRetryCount = 0;
        running = true;

        executeButton.setEnabled(false);
        executeButton.setText("PROCESSANDO...");

        addProgress(
                "INÍCIO",
                activeFlow == Flow.ACTIVATE
                        ? "Ativando MAC..."
                        : "Localizando MAC...",
                Color.rgb(255, 166, 0)
        );

        if (activeFlow == Flow.ACTIVATE) {
            webView.loadUrl(CREATE_USER + "?t=" + System.currentTimeMillis());
        } else {
            webView.loadUrl(USERS + "?t=" + System.currentTimeMillis());
        }
    }

    private String normalizeMac(String value) {
        String clean = value == null
                ? ""
                : value.trim().toUpperCase(Locale.ROOT);

        clean = clean.replace("-", ":");

        String hex = clean.replaceAll("[^A-F0-9]", "");

        if (hex.length() == 12) {
            StringBuilder out = new StringBuilder();

            for (int i = 0; i < 12; i += 2) {
                if (out.length() > 0) out.append(":");
                out.append(hex, i, i + 2);
            }

            return out.toString();
        }

        return clean;
    }

    private boolean isValidMac(String mac) {
        return mac != null
                && mac.matches("^([0-9A-F]{2}:){5}[0-9A-F]{2}$");
    }

    private void handlePageFinished(String url) {
        if (!running || url == null) return;

        String lower = url.toLowerCase(Locale.ROOT);

        if (loginOnlyMode) {
            if (isAuthenticatedUrl(lower)) {
                showAppScreen();
                return;
            }

            if (isLoginUrl(lower) && !loginInjected) {
                loginInjected = true;

                webView.evaluateJavascript(
                        JsScripts.login(
                                emailInput.getText().toString().trim(),
                                passwordInput.getText().toString()
                        ),
                        null
                );

                loginStatus.setText("Autenticando...");
                return;
            }

            // Em caso de rota intermediária, aguarda um pouco antes do fallback.
            handler.postDelayed(() -> {
                if (!loginOnlyMode || !running) return;

                String current = webView.getUrl();
                String c = current == null ? "" : current.toLowerCase(Locale.ROOT);

                if (isAuthenticatedUrl(c)) {
                    showAppScreen();
                } else if (!loginInjected && loginRetryCount < 2) {
                    loginRetryCount++;
                    webView.loadUrl(BASE + "?t=" + System.currentTimeMillis());
                }
            }, 1800);

            return;
        }

        if (activeFlow == Flow.ACTIVATE) {
            if (lower.contains("/users/create")) {
                if (!automationInjected) {
                    automationInjected = true;

                    webView.evaluateJavascript(
                            JsScripts.activate(
                                    currentMac,
                                    currentApp,
                                    currentServer,
                                    currentPlaylist
                            ),
                            null
                    );
                }
                return;
            }

            if (lower.contains("/users") && !lower.contains("/create")) {
                finishFlow("Ativação concluída.");
            }

            return;
        }

        if (activeFlow == Flow.EDIT_M3U) {
            if (lower.matches(".*\\/users\\/\\d+\\/edit.*")) {
                if (!automationInjected) {
                    automationInjected = true;

                    webView.evaluateJavascript(
                            JsScripts.editM3u(
                                    currentServer,
                                    currentPlaylist
                            ),
                            null
                    );
                }
                return;
            }

            if (lower.contains("/users") && !lower.contains("/create")) {
                if (!searchInjected) {
                    searchInjected = true;

                    webView.evaluateJavascript(
                            JsScripts.findUserAndOpenEdit(currentMac),
                            null
                    );
                }
            }
        }
    }

    private boolean isLoginUrl(String lower) {
        if (lower == null) return false;

        return lower.equals("https://gerenciaapp.top/")
                || lower.startsWith("https://gerenciaapp.top/?")
                || lower.contains("/login")
                || lower.contains("/signin");
    }

    private boolean isAuthenticatedUrl(String lower) {
        if (lower == null) return false;

        return lower.contains("/dashboard")
                || lower.contains("/users")
                || lower.contains("/menu");
    }

    private void onAutomationMessage(String raw) {
        runOnUiThread(() -> {
            try {
                JSONObject obj = new JSONObject(raw);

                String type = obj.optString("type", "progress");
                String code = obj.optString("code", "EVENT");
                String message = obj.optString("message", "");

                if (loginOnlyMode) {
                    if ("LOGIN_OK".equals(code)) {
                        return;
                    }

                    if ("error".equals(type)) {
                        if (loginRetryCount < 2) {
                            loginRetryCount++;
                            loginInjected = false;
                            loginStatus.setText("Tentando novamente...");
                            webView.loadUrl(BASE + "?t=" + System.currentTimeMillis());
                        } else {
                            loginOnlyMode = false;
                            running = false;
                            loginButton.setEnabled(true);
                            loginButton.setText("ENTRAR");
                            loginStatus.setText(message);
                        }
                    } else {
                        loginStatus.setText(message);
                    }

                    return;
                }

                if ("ACTIVATE_SUBMITTED".equals(code)) {
                    finishFlow("Ativação enviada com sucesso.");
                    return;
                }

                if ("EDIT_PAGE_FOUND".equals(code)) {
                    return;
                }

                if ("EDIT_SUBMITTED".equals(code)) {
                    finishFlow("M3U atualizada com sucesso.");
                    return;
                }

                if ("error".equals(type)) {
                    handleAutomationError(code, message);
                    return;
                }

                addProgress(code, message, Color.rgb(255, 166, 0));

            } catch (Exception error) {
                handleAutomationError(
                        "INVALID_MESSAGE",
                        "Resposta inválida do painel."
                );
            }
        });
    }

    private void handleAutomationError(String code, String message) {
        if (isRecoverableAutomationError(code) && automationRetryCount < 3) {
            automationRetryCount++;

            addProgress(
                    "RETRY",
                    "Tentativa automática "
                            + automationRetryCount
                            + "/3...",
                    Color.rgb(255, 166, 0)
            );

            handler.postDelayed(() -> {
                if (!running) return;

                automationInjected = false;
                searchInjected = false;

                if (activeFlow == Flow.ACTIVATE) {
                    webView.loadUrl(
                            CREATE_USER + "?t=" + System.currentTimeMillis()
                    );
                } else {
                    String current = webView.getUrl();

                    if (current != null
                            && current.toLowerCase(Locale.ROOT).matches(
                            ".*\\/users\\/\\d+\\/edit.*"
                    )) {
                        webView.reload();
                    } else {
                        webView.loadUrl(
                                USERS + "?t=" + System.currentTimeMillis()
                        );
                    }
                }
            }, 1000);

            return;
        }

        recordHistory(
                activeFlow,
                currentMac,
                "Falha",
                message
        );

        addProgress(
                "ERRO",
                message,
                Color.rgb(255, 92, 92)
        );

        stopBusyOnly();
    }

    private boolean isRecoverableAutomationError(String code) {
        return "CREATE_FORM_NOT_FOUND".equals(code)
                || "MAC_INPUT_NOT_FOUND".equals(code)
                || "APP_SELECT_NOT_FOUND".equals(code)
                || "PLAYLIST_FORM_NOT_READY".equals(code)
                || "PLAYLIST_INPUT_NOT_FOUND".equals(code)
                || "SEARCH_INPUT_NOT_FOUND".equals(code)
                || "EDIT_LINK_NOT_FOUND".equals(code)
                || "EDIT_FORM_NOT_READY".equals(code);
    }

    private void finishFlow(String message) {
        if (!running) return;

        recordHistory(
                activeFlow,
                currentMac,
                "Sucesso",
                message
        );

        addProgress(
                "CONCLUÍDO",
                message + " Pronto para o próximo dispositivo.",
                Color.rgb(0, 184, 255)
        );

        running = false;
        automationRetryCount = 0;

        macInput.setText("");
        playlistInput.setText("");
        currentMac = "";
        currentPlaylist = "";
        currentServer = "";
        currentApp = "";

        if (activeFlow == Flow.ACTIVATE) {
            serverInput.setText("Meu aplicativo");
            appSpinner.setSelection(0);
        } else {
            serverInput.setText("");
        }

        executeButton.setEnabled(true);
        executeButton.setText("EXECUTAR");

        macInput.requestFocus();
    }

    private void stopBusyOnly() {
        running = false;
        executeButton.setEnabled(true);
        executeButton.setText("EXECUTAR");
    }

    private void addProgress(String code, String message, int color) {
        progressList.removeAllViews();

        TextView line = new TextView(this);
        line.setText("● " + message);
        line.setTextColor(
                "ERRO".equals(code)
                        ? Color.rgb(255, 92, 92)
                        : "CONCLUÍDO".equals(code)
                        ? Color.rgb(0, 184, 255)
                        : color
        );
        line.setTextSize(18);
        line.setTypeface(null, 1);
        line.setPadding(0, dp(18), 0, dp(18));
        line.setGravity(Gravity.CENTER_VERTICAL);

        progressList.addView(line);
    }

    private void togglePanel() {
        boolean opening = webView.getVisibility() != View.VISIBLE;

        if (opening) {
            // REGRA FIXA: PAINEL sempre abre o dashboard principal.
            webView.loadUrl(
                    DASHBOARD + "?t=" + System.currentTimeMillis()
            );
            showPanel(true);
        } else {
            showPanel(false);
        }
    }

    private void showPanel(boolean show) {
        webView.setVisibility(show ? View.VISIBLE : View.GONE);
        consoleView.setVisibility(show ? View.GONE : View.VISIBLE);
        panelButton.setText(show ? "VOLTAR" : "PAINEL");
    }

    private void showSummary() {
        try {
            JSONArray history = new JSONArray(
                    securePrefs.getString("operation_history", "[]")
            );

            Calendar start = Calendar.getInstance();
            start.set(Calendar.HOUR_OF_DAY, 0);
            start.set(Calendar.MINUTE, 0);
            start.set(Calendar.SECOND, 0);
            start.set(Calendar.MILLISECOND, 0);

            int today = 0;
            int success = 0;
            int failed = 0;

            for (int i = 0; i < history.length(); i++) {
                JSONObject item = history.optJSONObject(i);
                if (item == null) continue;

                if (item.optLong("ts", 0L) >= start.getTimeInMillis()) {
                    today++;

                    if ("Sucesso".equals(item.optString("result"))) {
                        success++;
                    } else {
                        failed++;
                    }
                }
            }

            StringBuilder text = new StringBuilder();
            text.append("Sessão: Conectado\n");
            text.append("Versão: ")
                    .append(getInstalledVersionName())
                    .append("\n\n");
            text.append("Hoje\n");
            text.append("• Operações: ").append(today).append("\n");
            text.append("• Sucessos: ").append(success).append("\n");
            text.append("• Falhas: ").append(failed).append("\n\n");
            text.append("Últimas operações\n");

            if (history.length() == 0) {
                text.append("Nenhuma operação registrada.");
            } else {
                SimpleDateFormat format =
                        new SimpleDateFormat(
                                "dd/MM HH:mm",
                                Locale.getDefault()
                        );

                int shown = 0;

                for (int i = history.length() - 1;
                     i >= 0 && shown < 10;
                     i--) {

                    JSONObject item = history.optJSONObject(i);
                    if (item == null) continue;

                    text.append("\n")
                            .append("Sucesso".equals(
                                    item.optString("result")
                            ) ? "✓ " : "! ")
                            .append(format.format(
                                    new Date(item.optLong("ts"))
                            ))
                            .append(" • ")
                            .append(item.optString("device", "-"))
                            .append("\n   ")
                            .append(item.optString("flow", "-"))
                            .append(" • ")
                            .append(item.optString("result", "-"));

                    shown++;
                }
            }

            new AlertDialog.Builder(this)
                    .setTitle("RESUMO • MASTER IBO")
                    .setMessage(text.toString())
                    .setPositiveButton("FECHAR", null)
                    .setNeutralButton(
                            "LIMPAR HISTÓRICO",
                            (dialog, which) -> {
                                securePrefs.edit()
                                        .remove("operation_history")
                                        .apply();
                                toast("Histórico limpo.");
                            }
                    )
                    .show();

        } catch (Exception error) {
            toast("Não foi possível abrir o resumo.");
        }
    }

    private void recordHistory(
            Flow flow,
            String device,
            String result,
            String detail
    ) {
        if (device == null || device.trim().isEmpty()) return;

        try {
            JSONArray current = new JSONArray(
                    securePrefs.getString("operation_history", "[]")
            );

            JSONObject item = new JSONObject();
            item.put("ts", System.currentTimeMillis());
            item.put("device", device);
            item.put("flow", flowLabel(flow));
            item.put("result", result);

            // Nunca salva senha nem URL M3U no histórico.
            if (detail != null && !detail.isEmpty()) {
                item.put("detail", detail);
            }

            current.put(item);

            JSONArray trimmed = new JSONArray();
            int start = Math.max(0, current.length() - 50);

            for (int i = start; i < current.length(); i++) {
                trimmed.put(current.get(i));
            }

            securePrefs.edit()
                    .putString("operation_history", trimmed.toString())
                    .apply();

        } catch (Exception ignored) {
        }
    }

    private String flowLabel(Flow flow) {
        return flow == Flow.EDIT_M3U
                ? "Editar / Repor M3U"
                : "Ativar MAC + M3U";
    }

    private String getInstalledVersionName() {
        try {
            return getPackageManager()
                    .getPackageInfo(getPackageName(), 0)
                    .versionName;
        } catch (Exception error) {
            return "1.0.0";
        }
    }

    private int getDrawableId(String name, String type) {
        return getResources().getIdentifier(
                name,
                type,
                getPackageName()
        );
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private void toast(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE) {
            showPanel(false);
            return;
        }

        super.onBackPressed();
    }

    public class AutomationBridge {
        @JavascriptInterface
        public void postMessage(String message) {
            onAutomationMessage(message);
        }
    }

    private static class JsScripts {

        private static String quote(String value) {
            return JSONObject.quote(value);
        }

        private static String helpers() {
            return ""
                    + "function post(type,code,message){"
                    + "try{AutomationBridge.postMessage(JSON.stringify({type,code,message}));}catch(e){}"
                    + "}"
                    + "function setVal(el,val){"
                    + "if(!el)return;"
                    + "const proto=Object.getPrototypeOf(el);"
                    + "const d=Object.getOwnPropertyDescriptor(proto,'value');"
                    + "if(d&&d.set){d.set.call(el,val);}else{el.value=val;}"
                    + "el.dispatchEvent(new Event('input',{bubbles:true}));"
                    + "el.dispatchEvent(new Event('change',{bubbles:true}));"
                    + "}"
                    + "function clickReal(el){"
                    + "if(!el)return;"
                    + "['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>{"
                    + "try{el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window}));}catch(e){}"
                    + "});"
                    + "}"
                    + "function norm(s){"
                    + "return (s||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase().trim();"
                    + "}"
                    + "function labelText(el){"
                    + "let p=el.parentElement;let n=0;let out='';"
                    + "while(p&&n<4){out+=' '+(p.innerText||'');p=p.parentElement;n++;}"
                    + "return norm(out);"
                    + "}"
                    + "function selectText(sel,text){"
                    + "const target=norm(text);"
                    + "const opt=[...sel.options].find(o=>norm(o.textContent)===target)"
                    + "||[...sel.options].find(o=>norm(o.textContent).includes(target));"
                    + "if(!opt)return false;"
                    + "setVal(sel,opt.value);return true;"
                    + "}";
        }

        static String login(String email, String password) {
            return "(function(){"
                    + "const EMAIL=" + quote(email) + ";"
                    + "const PASSWORD=" + quote(password) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const emailInput=inputs.find(i=>i.type==='email')"
                    + "||inputs.find(i=>/email|e-mail/i.test(norm(i.placeholder)))"
                    + "||inputs.find(i=>/email/i.test(norm(i.name)));"
                    + "const passInput=inputs.find(i=>i.type==='password')"
                    + "||inputs.find(i=>/senha|password/i.test(norm(i.placeholder)));"
                    + "if(!emailInput||!passInput){"
                    + "if(n>=50){clearInterval(timer);post('error','LOGIN_FIELDS_NOT_FOUND','Campos de login não encontrados.');}"
                    + "return;"
                    + "}"
                    + "clearInterval(timer);"
                    + "post('progress','LOGIN_FILL','Autenticando...');"
                    + "setVal(emailInput,EMAIL);"
                    + "setVal(passInput,PASSWORD);"
                    + "const checks=inputs.filter(i=>i.type==='checkbox');"
                    + "const keep=checks.find(c=>labelText(c).includes('manter conectado'))||checks[0];"
                    + "if(keep&&!keep.checked)clickReal(keep);"
                    + "const form=passInput.closest('form')||emailInput.closest('form');"
                    + "const submit=(form&&form.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].find(b=>norm(b.textContent)==='entrar');"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(submit){clickReal(submit);}"
                    + "else if(form){form.submit();}"
                    + "else{post('error','LOGIN_BUTTON_NOT_FOUND','Botão Entrar não encontrado.');return;}"
                    + "post('progress','LOGIN_OK','Login enviado.');"
                    + "},400);"
                    + "})();true;";
        }

        static String activate(
                String mac,
                String appName,
                String serverName,
                String m3u
        ) {
            return "(function(){"
                    + "const MAC=" + quote(mac) + ";"
                    + "const APP=" + quote(appName) + ";"
                    + "const SERVER=" + quote(serverName) + ";"
                    + "const M3U=" + quote(m3u) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const form=document.querySelector('form');"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const selects=[...document.querySelectorAll('select')];"
                    + "if(!form||inputs.length===0){"
                    + "if(n>=50){clearInterval(timer);post('error','CREATE_FORM_NOT_FOUND','Formulário de cadastro não encontrado.');}"
                    + "return;"
                    + "}"
                    + "let macInput=inputs.find(i=>norm(i.placeholder).includes('00:00:00:00:00:00'))"
                    + "||inputs.find(i=>labelText(i).includes('mac do dispositivo'));"
                    + "if(!macInput){clearInterval(timer);post('error','MAC_INPUT_NOT_FOUND','Campo MAC não encontrado.');return;}"
                    + "let appSelect=selects.find(s=>[...s.options].some(o=>norm(o.textContent)===norm(APP)))"
                    + "||selects.find(s=>labelText(s).includes('app que o cliente'));"
                    + "if(!appSelect){"
                    + "if(n>=50){clearInterval(timer);post('error','APP_SELECT_NOT_FOUND','Lista de aplicativos não encontrada.');}"
                    + "return;"
                    + "}"
                    + "setVal(macInput,MAC);"
                    + "if(!selectText(appSelect,APP)){clearInterval(timer);post('error','APP_OPTION_NOT_FOUND','Aplicativo selecionado não existe no painel.');return;}"
                    + "const titleInput=inputs.find(i=>norm(i.placeholder).includes('titulo geral'));"
                    + "if(titleInput&&SERVER)setVal(titleInput,SERVER);"
                    + "const typeSelect=selects.find(s=>[...s.options].some(o=>norm(o.textContent)==='m3u8'));"
                    + "if(typeSelect)selectText(typeSelect,'M3U8');"
                    + "setTimeout(()=>{"
                    + "const all=[...document.querySelectorAll('input')];"
                    + "const server=all.find(i=>norm(i.placeholder).includes('nome do servidor'));"
                    + "const list=all.find(i=>norm(i.placeholder).includes('lista m3u8'))"
                    + "||all.find(i=>norm(i.placeholder).includes('m3u8')&&i!==server);"
                    + "if(!server||!list){post('error','PLAYLIST_FORM_NOT_READY','Campos da playlist M3U8 ainda não estão prontos.');return;}"
                    + "setVal(server,SERVER);"
                    + "setVal(list,M3U);"
                    + "post('progress','PLAYLIST_FILL','Adicionando M3U...');"
                    + "setTimeout(()=>{"
                    + "const forms=[...document.querySelectorAll('form')];"
                    + "const target=list.closest('form')||forms[forms.length-1]||form;"
                    + "if(target&&typeof target.reportValidity==='function'&&!target.reportValidity()){"
                    + "post('error','FORM_INVALID','O painel recusou algum campo obrigatório.');return;"
                    + "}"
                    + "const send=(target&&target.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].reverse().find(b=>norm(b.textContent)==='enviar');"
                    + "if(target&&typeof target.requestSubmit==='function'){target.requestSubmit();}"
                    + "else if(send){clickReal(send);}"
                    + "else{post('error','SUBMIT_NOT_FOUND','Botão Enviar não encontrado.');return;}"
                    + "post('success','ACTIVATE_SUBMITTED','Ativação enviada.');"
                    + "},700);"
                    + "},700);"
                    + "clearInterval(timer);"
                    + "},400);"
                    + "})();true;";
        }

        static String findUserAndOpenEdit(String mac) {
            return "(function(){"
                    + "const MAC=" + quote(mac) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const search=inputs.find(i=>norm(i.placeholder).startsWith('buscar'))"
                    + "||inputs.find(i=>labelText(i).includes('lista de usuarios')&&i.type==='text');"
                    + "if(!search){"
                    + "if(n>=40){clearInterval(timer);post('error','SEARCH_INPUT_NOT_FOUND','Busca de usuários não encontrada.');}"
                    + "return;"
                    + "}"
                    + "setVal(search,MAC);"
                    + "const button=[...document.querySelectorAll('button')].find(b=>norm(b.textContent)==='buscar');"
                    + "if(button)clickReal(button);"
                    + "clearInterval(timer);"
                    + "post('progress','SEARCHING_USER','Localizando MAC...');"
                    + "let wait=0;"
                    + "const result=setInterval(()=>{"
                    + "wait++;"
                    + "const macNorm=norm(MAC);"
                    + "const nodes=[...document.querySelectorAll('body *')].filter(e=>norm(e.textContent).includes(macNorm));"
                    + "let edit=null;"
                    + "for(const node of nodes){"
                    + "let p=node;"
                    + "for(let depth=0;p&&depth<7;depth++,p=p.parentElement){"
                    + "const a=p.querySelector&&p.querySelector('a[href*=\"/users/\"][href*=\"/edit\"]');"
                    + "if(a){edit=a;break;}"
                    + "}"
                    + "if(edit)break;"
                    + "}"
                    + "if(!edit){"
                    + "const links=[...document.querySelectorAll('a[href*=\"/users/\"][href*=\"/edit\"]')];"
                    + "if(links.length===1)edit=links[0];"
                    + "}"
                    + "if(edit){"
                    + "clearInterval(result);"
                    + "post('progress','EDIT_PAGE_FOUND','Abrindo edição do usuário...');"
                    + "window.location.href=edit.href;"
                    + "return;"
                    + "}"
                    + "if(wait>=30){clearInterval(result);post('error','EDIT_LINK_NOT_FOUND','Usuário encontrado, mas a edição não ficou disponível.');}"
                    + "},500);"
                    + "},400);"
                    + "})();true;";
        }

        static String editM3u(String serverName, String m3u) {
            return "(function(){"
                    + "const SERVER=" + quote(serverName) + ";"
                    + "const M3U=" + quote(m3u) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const selects=[...document.querySelectorAll('select')];"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "if(selects.length===0||inputs.length===0){"
                    + "if(n>=50){clearInterval(timer);post('error','EDIT_FORM_NOT_READY','Formulário de edição não carregou.');}"
                    + "return;"
                    + "}"
                    + "let typeSelect=selects.find(s=>{"
                    + "const selected=s.options[s.selectedIndex];"
                    + "return selected&&norm(selected.textContent)==='m3u8';"
                    + "});"
                    + "if(!typeSelect){"
                    + "typeSelect=selects.find(s=>[...s.options].some(o=>norm(o.textContent)==='m3u8'));"
                    + "}"
                    + "if(!typeSelect){"
                    + "const add=[...document.querySelectorAll('button')].find(b=>norm(b.textContent).includes('adicionar playlist'));"
                    + "if(add){clickReal(add);return;}"
                    + "if(n>=50){clearInterval(timer);post('error','PLAYLIST_INPUT_NOT_FOUND','Playlist M3U8 não encontrada.');}"
                    + "return;"
                    + "}"
                    + "selectText(typeSelect,'M3U8');"
                    + "let box=typeSelect.parentElement;"
                    + "for(let d=0;box&&d<5;d++){"
                    + "const txt=norm(box.innerText);"
                    + "if(txt.includes('playlist'))break;"
                    + "box=box.parentElement;"
                    + "}"
                    + "box=box||document;"
                    + "setTimeout(()=>{"
                    + "const local=[...box.querySelectorAll('input')];"
                    + "const server=local.find(i=>norm(i.placeholder).includes('nome do servidor'));"
                    + "const list=local.find(i=>norm(i.placeholder).includes('lista m3u8'))"
                    + "||local.find(i=>/^https?:\\/\\//i.test(i.value||''));"
                    + "if(!list){post('error','PLAYLIST_INPUT_NOT_FOUND','Campo da M3U8 não encontrado.');return;}"
                    + "if(server&&SERVER)setVal(server,SERVER);"
                    + "setVal(list,M3U);"
                    + "post('progress','EDITING_M3U','Atualizando M3U...');"
                    + "const form=list.closest('form')||document.querySelector('form');"
                    + "setTimeout(()=>{"
                    + "if(form&&typeof form.reportValidity==='function'&&!form.reportValidity()){"
                    + "post('error','FORM_INVALID','O painel recusou algum campo obrigatório.');return;"
                    + "}"
                    + "const send=(form&&form.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].reverse().find(b=>norm(b.textContent)==='enviar');"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(send){clickReal(send);}"
                    + "else{post('error','SUBMIT_NOT_FOUND','Botão Enviar não encontrado.');return;}"
                    + "post('success','EDIT_SUBMITTED','M3U atualizada.');"
                    + "},700);"
                    + "},500);"
                    + "clearInterval(timer);"
                    + "},400);"
                    + "})();true;";
        }
    }
}
