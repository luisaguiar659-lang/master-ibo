# MASTER IBO — Android nativo

Versão inicial: **1.0.0**

## Painel

- Login: `https://gerenciaapp.top/`
- Dashboard: `https://gerenciaapp.top/dashboard`
- Usuários: `https://gerenciaapp.top/users`
- Cadastro: `https://gerenciaapp.top/users/create`

## Funções da v1.0

1. **Ativar MAC + M3U**
   - informa o MAC;
   - escolhe o aplicativo do cliente no próprio MASTER IBO;
   - informa nome do servidor;
   - informa a URL M3U;
   - o app abre `/users/create`, seleciona M3U8 e envia o cadastro.

2. **Editar / Repor M3U**
   - localiza o usuário pelo MAC em `/users`;
   - abre a rota `/users/{id}/edit`;
   - localiza uma playlist M3U8;
   - troca a URL e, se informado, o nome do servidor;
   - envia a alteração.

## Aplicativos disponíveis

- FACILITA
- Gerencia Max
- GPC PRO ANDROID
- IBO REVENDA
- IBONEW
- TV ROKU - GPC PRO
- UNI REVENDA
- VU REVENDA
- ZONE X

## Regras da interface

- `PAINEL` sempre força `https://gerenciaapp.top/dashboard`.
- `RESUMO` mostra histórico e resultados locais.
- `SAIR` remove credenciais/cookies.
- Status mostra somente uma mensagem por vez.
- Após sucesso, MAC e M3U são limpos.
- Não existe função de exclusão de MAC nesta versão.

## Segurança

- E-mail e senha ficam em `EncryptedSharedPreferences`.
- A URL M3U não é salva no histórico.
- O WebView bloqueia navegação fora de `gerenciaapp.top`.

## Build no GitHub

O projeto já inclui `.github/workflows/build-apk.yml`.

Após enviar o conteúdo deste projeto para um repositório GitHub:

1. Abra **Actions**.
2. Execute **Build MASTER IBO APK**.
3. Ao terminar, baixe o artifact **MASTER-IBO-APK**.
4. Dentro dele estará `MASTER-IBO.apk`.

## Observação da v1.0

Os seletores da automação foram preparados com base na estrutura atual do painel
e nas telas mapeadas. Como o painel é um site externo, alterações futuras no HTML
podem exigir ajustes nos seletores JavaScript.


## MASTER IBO 1.1

- Adicionado gesto **puxar para baixo para atualizar**:
  - funciona na tela principal;
  - funciona dentro do PAINEL;
  - atualiza a sessão/página;
  - se a sessão tiver expirado, tenta reconectar automaticamente.
- Corrigido o fluxo **Editar / Repor M3U**:
  - busca mais robusta do usuário pelo MAC;
  - identifica ID do usuário em links, formulários, rotas, atributos e HTML do card;
  - suporta painel que recarrega a página após clicar em Buscar;
  - tenta abrir botão/ação "Editar" quando a rota não está exposta diretamente.
- Mantida a regra fixa:
  - `PAINEL` sempre abre `https://gerenciaapp.top/dashboard`.


## MASTER IBO 1.2.1

- O aplicativo não faz mais login automaticamente ao abrir.
- E-mail e senha continuam salvos/preenchidos.
- O login só é executado quando o usuário toca em `ENTRAR`.
- Mantidas todas as funções da v1.1.
