# MASTER IBO v1.2.2

Base: v1.2.1.

## Atualização
A interface completa foi adaptada para diferentes tamanhos e densidades de tela.

### Responsividade
- login em ScrollView;
- teclado com adjustResize;
- barra superior adaptativa;
- logo, títulos e botões adaptativos;
- formulário com largura útil máxima em telas grandes;
- margens e espaçamentos reduzidos em telas compactas;
- campos, seletores e botão EXECUTAR adaptativos;
- WebView com wide viewport + overview mode;
- suporte a celulares pequenos, médios, grandes e tablets.

### Assinatura
A versão foi preparada para assinatura release permanente com 4 Repository Secrets:
- IBO_ANDROID_KEYSTORE_BASE64
- IBO_ANDROID_KEYSTORE_PASSWORD
- IBO_ANDROID_KEY_ALIAS
- IBO_ANDROID_KEY_PASSWORD

Versão: 1.2.2
versionCode: 4
