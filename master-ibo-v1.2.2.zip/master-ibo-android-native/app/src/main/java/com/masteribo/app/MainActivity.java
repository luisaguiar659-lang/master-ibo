package com.masteribo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.security.crypto.MasterKey;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String BASE = "https://gerenciaapp.top/";
    private static final String DASHBOARD = "https://gerenciaapp.top/dashboard";
    private static final String USERS = "https://gerenciaapp.top/users";
    private static final String CREATE_USER = "https://gerenciaapp.top/users/create";

    private static final Set<String> ALLOWED_HOSTS = new HashSet<>(Arrays.asList(
            "gerenciaapp.top",
            "www.gerenciaapp.top"
    ));

    private enum Flow {
        ACTIVATE,
        EDIT_M3U
    }

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private ScrollView consoleView;
    private LinearLayout progressList;
    private ScrollView loginScreen;
    private LinearLayout appScreen;
    private SwipeRefreshLayout refreshLayout;

    private TextView loginStatus;
    private TextView connectionStatus;
    private TextView appLabel;
    private TextView serverLabel;

    private EditText emailInput;
    private EditText passwordInput;
    private EditText macInput;
    private EditText serverInput;
    private EditText playlistInput;

    private Spinner flowSpinner;
    private Spinner appSpinner;

    private Button executeButton;
    private Button panelButton;
    private Button summaryButton;
    private Button logoutButton;
    private Button loginButton;

    private SharedPreferences securePrefs;

    private Flow activeFlow = Flow.ACTIVATE;

    private boolean authenticated = false;
    private boolean running = false;
    private boolean loginOnlyMode = false;
    private boolean loginInjected = false;
    private boolean automationInjected = false;
    private boolean searchInjected = false;
    private int loginRetryCount = 0;
    private int automationRetryCount = 0;
    private boolean manualRefreshing = false;

    private String currentMac = "";
    private String currentPlaylist = "";
    private String currentServer = "";
    private String currentApp = "";

    private final String[] apps = new String[]{
            "Selecione um aplicativo",
            "FACILITA",
            "Gerencia Max",
            "GPC PRO ANDROID",
            "IBO REVENDA",
            "IBONEW",
            "TV ROKU - GPC PRO",
            "UNI REVENDA",
            "VU REVENDA",
            "ZONE X"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        securePrefs = createSecurePreferences();
        buildUi();
        setupWebView();
        loadSavedCredentials();

        showLoginScreen();

        // As credenciais podem continuar salvas/preenchidas,
        // mas o login só acontece quando o usuário toca em ENTRAR.
        if (!emailInput.getText().toString().trim().isEmpty()
                && !passwordInput.getText().toString().isEmpty()) {
            loginStatus.setText("Credenciais salvas. Toque em ENTRAR.");
        }
    }

    private SharedPreferences createSecurePreferences() {
        try {
            MasterKey key = new MasterKey.Builder(this)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            return EncryptedSharedPreferences.create(
                    this,
                    "master_ibo_secure",
                    key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception error) {
            throw new RuntimeException("Falha ao inicializar armazenamento seguro.", error);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setUserAgentString(
                settings.getUserAgentString() + " MasterIBO/1.0"
        );

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AutomationBridge(), "AutomationBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request
            ) {
                String host = request.getUrl().getHost();

                if (host == null || !ALLOWED_HOSTS.contains(host)) {
                    toast("Navegação externa bloqueada.");
                    return true;
                }

                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                handlePageFinished(url);
            }
        });
    }

    private void buildUi() {
        int screenWidthDp =
                currentWidthDp();

        int screenHeightDp =
                currentHeightDp();

        boolean veryCompactUi =
                screenWidthDp < 340
                        || screenHeightDp < 560;

        boolean compactUi =
                screenWidthDp < 380
                        || screenHeightDp < 700;

        boolean wideUi =
                screenWidthDp >= 600;

        boolean tabletUi =
                screenWidthDp >= 840;

        int pad =
                dp(
                        veryCompactUi
                                ? 8
                                : (compactUi ? 10 : 16)
                );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(
                pad,
                dp(veryCompactUi ? 6 : (compactUi ? 8 : 14)),
                pad,
                dp(veryCompactUi ? 4 : (compactUi ? 6 : 10))
        );

        TextView title = new TextView(this);
        title.setText(
                veryCompactUi
                        ? "IBO"
                        : "MASTER IBO"
        );
        title.setTextColor(Color.WHITE);
        title.setTextSize(
                veryCompactUi
                        ? 15
                        : (compactUi ? 18 : 21)
        );
        title.setTypeface(null, 1);
        title.setLetterSpacing(0.02f);

        topBar.addView(
                title,
                new LinearLayout.LayoutParams(
                        0,
                        dp(veryCompactUi ? 40 : (compactUi ? 44 : 48)),
                        1f
                )
        );

        panelButton = topButton(
                "PAINEL",
                veryCompactUi,
                compactUi
        );
        panelButton.setOnClickListener(v -> togglePanel());
        topBar.addView(panelButton);

        summaryButton = topButton(
                compactUi ? "INFO" : "RESUMO",
                veryCompactUi,
                compactUi
        );
        summaryButton.setOnClickListener(v -> showSummary());
        topBar.addView(summaryButton);

        logoutButton = topButton(
                "SAIR",
                veryCompactUi,
                compactUi
        );
        logoutButton.setOnClickListener(v -> logout());
        topBar.addView(logoutButton);

        root.addView(topBar);

        View glowLine = new View(this);
        glowLine.setBackgroundResource(getDrawableId("bg_glow_line", "drawable"));
        root.addView(
                glowLine,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(3)
                )
        );

        // LOGIN RESPONSIVO
        boolean compactLogin =
                compactUi;

        boolean wideLogin =
                wideUi;

        int loginHorizontalPadding;

        if (wideLogin) {
            loginHorizontalPadding =
                    Math.max(
                            28,
                            (screenWidthDp - 480) / 2
                    );
        } else if (screenWidthDp < 360) {
            loginHorizontalPadding =
                    16;
        } else {
            loginHorizontalPadding =
                    22;
        }

        int loginTopPadding =
                compactLogin
                        ? 12
                        : 26;

        int loginBottomPadding =
                compactLogin
                        ? 24
                        : 40;

        int logoSize =
                veryCompactUi
                        ? 96
                        : (compactLogin ? 112 : (wideLogin ? 176 : 150));

        int loginTitleSize =
                veryCompactUi
                        ? 21
                        : (compactLogin ? 23 : 28);

        int loginSubtitleSize =
                compactLogin
                        ? 12
                        : 14;

        loginScreen =
                new ScrollView(
                        this
                );
        loginScreen.setFillViewport(true);
        loginScreen.setClipToPadding(false);
        loginScreen.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        LinearLayout loginContent =
                new LinearLayout(
                        this
                );
        loginContent.setOrientation(LinearLayout.VERTICAL);
        loginContent.setGravity(Gravity.CENTER_HORIZONTAL);
        loginContent.setPadding(
                dp(loginHorizontalPadding),
                dp(loginTopPadding),
                dp(loginHorizontalPadding),
                dp(loginBottomPadding)
        );

        ImageView loginLogo = new ImageView(this);
        loginLogo.setImageResource(getDrawableId("logo_master_ibo", "drawable"));
        loginLogo.setAdjustViewBounds(true);
        loginLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(
                        dp(logoSize),
                        dp(logoSize)
                );
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        loginLogo.setLayoutParams(logoParams);
        loginContent.addView(loginLogo);

        loginContent.addView(
                verticalSpace(
                        compactLogin ? 4 : 10
                )
        );

        TextView loginTitle = new TextView(this);
        loginTitle.setText("MASTER IBO");
        loginTitle.setTextColor(Color.WHITE);
        loginTitle.setTextSize(loginTitleSize);
        loginTitle.setTypeface(null, 1);
        loginTitle.setGravity(Gravity.CENTER_HORIZONTAL);
        loginContent.addView(
                loginTitle,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        TextView loginSubtitle = new TextView(this);
        loginSubtitle.setText("Entre para acessar a automação IBO.");
        loginSubtitle.setTextColor(Color.rgb(168, 179, 188));
        loginSubtitle.setTextSize(loginSubtitleSize);
        loginSubtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        loginSubtitle.setPadding(
                0,
                dp(compactLogin ? 4 : 8),
                0,
                dp(compactLogin ? 16 : 28)
        );
        loginContent.addView(
                loginSubtitle,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        emailInput = field("E-mail", false);
        passwordInput = field("Senha", true);

        emailInput.setSingleLine(true);
        passwordInput.setSingleLine(true);

        emailInput.setImeOptions(
                android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
        );
        passwordInput.setImeOptions(
                android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        );

        loginContent.addView(
                emailInput,
                matchHeight(
                        dp(veryCompactUi ? 46 : (compactLogin ? 50 : 54))
                )
        );
        loginContent.addView(
                verticalSpace(
                        compactLogin ? 8 : 12
                )
        );
        loginContent.addView(
                passwordInput,
                matchHeight(
                        dp(veryCompactUi ? 46 : (compactLogin ? 50 : 54))
                )
        );
        loginContent.addView(
                verticalSpace(
                        compactLogin ? 10 : 12
                )
        );

        loginButton = new Button(this);
        loginButton.setText("ENTRAR");
        loginButton.setTextSize(
                veryCompactUi
                        ? 13
                        : (compactLogin ? 14 : 15)
        );
        loginButton.setTypeface(null, 1);
        loginButton.setTextColor(Color.WHITE);
        loginButton.setBackgroundResource(getDrawableId("bg_login_gradient", "drawable"));
        loginButton.setOnClickListener(v -> authenticateOnly());
        loginContent.addView(
                loginButton,
                matchHeight(
                        dp(veryCompactUi ? 48 : (compactLogin ? 52 : 56))
                )
        );

        loginStatus = new TextView(this);
        loginStatus.setText("");
        loginStatus.setTextColor(Color.rgb(0, 184, 255));
        loginStatus.setTextSize(
                compactLogin
                        ? 12
                        : 13
        );
        loginStatus.setGravity(Gravity.CENTER_HORIZONTAL);
        loginStatus.setPadding(
                0,
                dp(compactLogin ? 12 : 18),
                0,
                0
        );
        loginContent.addView(
                loginStatus,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        loginScreen.addView(
                loginContent,
                new ScrollView.LayoutParams(
                        ScrollView.LayoutParams.MATCH_PARENT,
                        ScrollView.LayoutParams.WRAP_CONTENT
                )
        );

        root.addView(
                loginScreen,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        // APP RESPONSIVO
        appScreen = new LinearLayout(this);
        appScreen.setOrientation(LinearLayout.VERTICAL);
        appScreen.setVisibility(View.GONE);

        consoleView = new ScrollView(this);
        consoleView.setFillViewport(true);

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);

        int formHorizontalPadding;

        if (tabletUi) {
            formHorizontalPadding =
                    Math.max(
                            32,
                            (screenWidthDp - 720) / 2
                    );
        } else if (wideUi) {
            formHorizontalPadding =
                    Math.max(
                            24,
                            (screenWidthDp - 560) / 2
                    );
        } else if (veryCompactUi) {
            formHorizontalPadding =
                    10;
        } else if (compactUi) {
            formHorizontalPadding =
                    14;
        } else {
            formHorizontalPadding =
                    18;
        }

        form.setPadding(
                dp(formHorizontalPadding),
                dp(veryCompactUi ? 10 : (compactUi ? 14 : 20)),
                dp(formHorizontalPadding),
                dp(veryCompactUi ? 22 : (compactUi ? 28 : 40))
        );

        LinearLayout brandCard = new LinearLayout(this);
        brandCard.setOrientation(LinearLayout.HORIZONTAL);
        brandCard.setGravity(Gravity.CENTER_VERTICAL);
        brandCard.setPadding(
                dp(veryCompactUi ? 9 : (compactUi ? 11 : 14)),
                dp(veryCompactUi ? 8 : (compactUi ? 10 : 12)),
                dp(veryCompactUi ? 9 : (compactUi ? 11 : 14)),
                dp(veryCompactUi ? 8 : (compactUi ? 10 : 12))
        );
        brandCard.setBackgroundResource(getDrawableId("bg_card", "drawable"));

        ImageView miniLogo = new ImageView(this);
        miniLogo.setImageResource(getDrawableId("logo_master_ibo", "drawable"));

        int miniLogoSize =
                veryCompactUi
                        ? 44
                        : (compactUi ? 52 : (wideUi ? 74 : 68));

        brandCard.addView(
                miniLogo,
                new LinearLayout.LayoutParams(
                        dp(miniLogoSize),
                        dp(miniLogoSize)
                )
        );

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(
                dp(veryCompactUi ? 8 : 12),
                0,
                0,
                0
        );

        TextView brandName = new TextView(this);
        brandName.setText("MASTER IBO");
        brandName.setTextColor(Color.WHITE);
        brandName.setTextSize(
                veryCompactUi
                        ? 15
                        : (compactUi ? 17 : 19)
        );
        brandName.setTypeface(null, 1);

        connectionStatus = new TextView(this);
        connectionStatus.setText("● Conectado");
        connectionStatus.setTextColor(Color.rgb(0, 184, 255));
        connectionStatus.setTextSize(
                veryCompactUi
                        ? 10
                        : (compactUi ? 11 : 12)
        );

        brandText.addView(brandName);
        brandText.addView(connectionStatus);

        brandCard.addView(
                brandText,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        form.addView(brandCard);
        form.addView(sectionGap());
        form.addView(sectionTitle("PAINEL DE AUTOMAÇÃO"));

        flowSpinner = new Spinner(this);
        ArrayAdapter<String> flowAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{
                        "Ativar MAC + M3U",
                        "Editar / Repor M3U"
                }
        );
        flowSpinner.setAdapter(flowAdapter);
        flowSpinner.setBackgroundResource(getDrawableId("bg_input", "drawable"));
        form.addView(
                flowSpinner,
                matchHeight(
                        dp(veryCompactUi ? 46 : (compactUi ? 50 : 56))
                )
        );

        form.addView(space());

        macInput = field("MAC do dispositivo", false);
        macInput.setMinHeight(
                dp(veryCompactUi ? 46 : (compactUi ? 50 : 54))
        );
        form.addView(macInput);

        form.addView(space());

        appLabel = sectionFieldLabel("APLICATIVO DO CLIENTE");
        form.addView(appLabel);

        appSpinner = new Spinner(this);
        ArrayAdapter<String> appAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                apps
        );
        appSpinner.setAdapter(appAdapter);
        appSpinner.setBackgroundResource(getDrawableId("bg_input", "drawable"));
        form.addView(
                appSpinner,
                matchHeight(
                        dp(veryCompactUi ? 46 : (compactUi ? 50 : 56))
                )
        );

        form.addView(space());

        serverLabel = sectionFieldLabel("NOME DO SERVIDOR");
        form.addView(serverLabel);

        serverInput = field("Nome do servidor", false);
        serverInput.setText("Meu aplicativo");
        serverInput.setMinHeight(
                dp(veryCompactUi ? 46 : (compactUi ? 50 : 54))
        );
        form.addView(serverInput);

        form.addView(space());

        playlistInput = field("URL M3U", false);
        playlistInput.setMinLines(
                veryCompactUi
                        ? 1
                        : 2
        );
        playlistInput.setMaxLines(
                compactUi
                        ? 3
                        : 5
        );
        playlistInput.setGravity(Gravity.TOP);
        form.addView(playlistInput);

        form.addView(space());

        executeButton = new Button(this);
        executeButton.setText("EXECUTAR");
        executeButton.setTextSize(
                veryCompactUi
                        ? 13
                        : (compactUi ? 14 : 15)
        );
        executeButton.setTypeface(null, 1);
        executeButton.setTextColor(Color.WHITE);
        executeButton.setBackgroundResource(getDrawableId("bg_action_gradient", "drawable"));
        executeButton.setOnClickListener(v -> startFlow());
        form.addView(
                executeButton,
                matchHeight(
                        dp(veryCompactUi ? 48 : (compactUi ? 52 : 56))
                )
        );

        form.addView(sectionGap());
        form.addView(sectionTitle("STATUS DA AUTOMAÇÃO"));

        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(
                dp(veryCompactUi ? 9 : (compactUi ? 11 : 14)),
                dp(veryCompactUi ? 7 : 10),
                dp(veryCompactUi ? 9 : (compactUi ? 11 : 14)),
                dp(veryCompactUi ? 7 : 10)
        );
        statusCard.setBackgroundResource(getDrawableId("bg_card", "drawable"));

        progressList = new LinearLayout(this);
        progressList.setOrientation(LinearLayout.VERTICAL);
        statusCard.addView(progressList);
        form.addView(statusCard);

        addProgress("PRONTO", "Pronto para iniciar.", Color.rgb(136, 148, 139));

        consoleView.addView(form);

        appScreen.addView(
                consoleView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        webView = new WebView(this);
        webView.setVisibility(View.GONE);

        appScreen.addView(
                webView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        refreshLayout = new SwipeRefreshLayout(this);
        refreshLayout.setColorSchemeColors(
                Color.rgb(255, 145, 0),
                Color.rgb(0, 184, 255)
        );

        refreshLayout.setOnChildScrollUpCallback((parent, child) -> {
            View target = webView.getVisibility() == View.VISIBLE
                    ? webView
                    : consoleView;
            return target != null && target.canScrollVertically(-1);
        });

        refreshLayout.setOnRefreshListener(this::refreshCurrentScreen);

        refreshLayout.addView(
                appScreen,
                new SwipeRefreshLayout.LayoutParams(
                        SwipeRefreshLayout.LayoutParams.MATCH_PARENT,
                        SwipeRefreshLayout.LayoutParams.MATCH_PARENT
                )
        );

        root.addView(
                refreshLayout,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        flowSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(
                    AdapterView<?> parent,
                    View view,
                    int position,
                    long id
            ) {
                boolean activate = position == 0;
                appLabel.setVisibility(activate ? View.VISIBLE : View.GONE);
                appSpinner.setVisibility(activate ? View.VISIBLE : View.GONE);

                if (activate && serverInput.getText().toString().trim().isEmpty()) {
                    serverInput.setText("Meu aplicativo");
                }

                if (!activate) {
                    serverInput.setText("");
                    serverInput.setHint("Nome do servidor (opcional)");
                } else {
                    serverInput.setHint("Nome do servidor");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        setContentView(root);
    }

    private Button topButton(
            String text,
            boolean veryCompact,
            boolean compact
    ) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(
                veryCompact
                        ? 9
                        : (compact ? 10 : 11)
        );
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(
                dp(veryCompact ? 5 : (compact ? 7 : 10)),
                0,
                dp(veryCompact ? 5 : (compact ? 7 : 10)),
                0
        );
        button.setTextColor(Color.WHITE);
        button.setBackgroundResource(getDrawableId("bg_secondary_button", "drawable"));
        button.setVisibility(View.GONE);
        return button;
    }

    private TextView sectionTitle(String text) {
        boolean compact =
                currentWidthDp() < 380
                        || currentHeightDp() < 700;

        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(255, 156, 0));
        view.setTextSize(compact ? 11 : 12);
        view.setTypeface(null, 1);
        view.setLetterSpacing(compact ? 0.05f : 0.08f);
        view.setPadding(
                0,
                0,
                0,
                dp(compact ? 8 : 12)
        );
        return view;
    }

    private TextView sectionFieldLabel(String text) {
        boolean compact =
                currentWidthDp() < 380
                        || currentHeightDp() < 700;

        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(168, 179, 188));
        view.setTextSize(compact ? 10 : 11);
        view.setTypeface(null, 1);
        view.setLetterSpacing(compact ? 0.04f : 0.06f);
        view.setPadding(
                0,
                0,
                0,
                dp(compact ? 4 : 6)
        );
        return view;
    }

    private EditText field(String hint, boolean password) {
        boolean veryCompact =
                currentWidthDp() < 340
                        || currentHeightDp() < 560;

        boolean compact =
                currentWidthDp() < 380
                        || currentHeightDp() < 700;

        EditText view = new EditText(this);
        view.setHint(hint);
        view.setHintTextColor(Color.rgb(120, 132, 142));
        view.setTextColor(Color.WHITE);
        view.setTextSize(
                veryCompact
                        ? 13
                        : (compact ? 14 : 15)
        );
        view.setPadding(
                dp(veryCompact ? 10 : (compact ? 12 : 16)),
                dp(veryCompact ? 9 : (compact ? 11 : 14)),
                dp(veryCompact ? 10 : (compact ? 12 : 16)),
                dp(veryCompact ? 9 : (compact ? 11 : 14))
        );
        view.setBackgroundResource(getDrawableId("bg_input", "drawable"));

        if (password) {
            view.setInputType(
                    InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD
            );
        }

        return view;
    }

    private View verticalSpace(
            int heightDp
    ) {
        View view = new View(this);
        view.setLayoutParams(
                new LinearLayout.LayoutParams(
                        1,
                        dp(heightDp)
                )
        );
        return view;
    }

    private View space() {
        boolean compact =
                currentWidthDp() < 380
                        || currentHeightDp() < 700;

        View v = new View(this);
        v.setLayoutParams(
                new LinearLayout.LayoutParams(
                        1,
                        dp(compact ? 8 : 12)
                )
        );
        return v;
    }

    private View sectionGap() {
        boolean compact =
                currentWidthDp() < 380
                        || currentHeightDp() < 700;

        View v = new View(this);
        v.setLayoutParams(
                new LinearLayout.LayoutParams(
                        1,
                        dp(compact ? 18 : 28)
                )
        );
        return v;
    }

    private LinearLayout.LayoutParams matchHeight(int height) {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                height
        );
    }

    private int currentWidthDp() {
        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(
                getResources()
                        .getDisplayMetrics()
                        .widthPixels
                        / density
        );
    }

    private int currentHeightDp() {
        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(
                getResources()
                        .getDisplayMetrics()
                        .heightPixels
                        / density
        );
    }

    private void showLoginScreen() {
        authenticated = false;
        loginScreen.setVisibility(View.VISIBLE);
        if (refreshLayout != null) {
            refreshLayout.setVisibility(View.GONE);
            refreshLayout.setRefreshing(false);
        }
        appScreen.setVisibility(View.GONE);
        panelButton.setVisibility(View.GONE);
        summaryButton.setVisibility(View.GONE);
        logoutButton.setVisibility(View.GONE);
    }

    private void showAppScreen() {
        authenticated = true;
        loginOnlyMode = false;
        running = false;

        loginScreen.setVisibility(View.GONE);
        if (refreshLayout != null) {
            refreshLayout.setVisibility(View.VISIBLE);
            refreshLayout.setRefreshing(false);
        }
        appScreen.setVisibility(View.VISIBLE);
        consoleView.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);

        panelButton.setVisibility(View.VISIBLE);
        summaryButton.setVisibility(View.VISIBLE);
        logoutButton.setVisibility(View.VISIBLE);

        connectionStatus.setText("● Conectado");
        connectionStatus.setTextColor(Color.rgb(0, 184, 255));

        loginButton.setEnabled(true);
        loginButton.setText("ENTRAR");
        loginStatus.setText("");
        loginRetryCount = 0;
    }

    private void refreshCurrentScreen() {
        if (!authenticated) {
            refreshLayout.setRefreshing(false);
            return;
        }

        if (running) {
            refreshLayout.setRefreshing(false);
            toast("Aguarde a automação terminar.");
            return;
        }

        manualRefreshing = true;

        if (webView.getVisibility() == View.VISIBLE) {
            webView.reload();
        } else {
            addProgress(
                    "ATUALIZANDO",
                    "Atualizando...",
                    Color.rgb(255, 166, 0)
            );

            // Atualiza a sessão/painel em segundo plano sem sair da tela principal.
            webView.loadUrl(
                    DASHBOARD + "?refresh=" + System.currentTimeMillis()
            );
        }

        handler.postDelayed(() -> {
            if (!manualRefreshing) return;

            manualRefreshing = false;

            if (refreshLayout != null) {
                refreshLayout.setRefreshing(false);
            }

            if (consoleView.getVisibility() == View.VISIBLE) {
                addProgress(
                        "PRONTO",
                        "Atualização concluída. Pronto para iniciar.",
                        Color.rgb(136, 148, 139)
                );
            }
        }, 10000);
    }

    private void authenticateOnly() {
        if (loginOnlyMode) return;

        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            toast("Informe e-mail e senha.");
            return;
        }

        saveCredentials();

        loginOnlyMode = true;
        running = true;
        authenticated = false;
        loginInjected = false;
        loginRetryCount = 0;

        loginButton.setEnabled(false);
        loginButton.setText("ENTRANDO...");
        loginStatus.setText("Verificando sessão salva...");

        // Primeiro tenta reaproveitar a sessão existente.
        webView.loadUrl(DASHBOARD + "?t=" + System.currentTimeMillis());
    }

    private void logout() {
        running = false;
        authenticated = false;
        loginOnlyMode = false;

        securePrefs.edit()
                .remove("email")
                .remove("password")
                .apply();

        emailInput.setText("");
        passwordInput.setText("");

        webView.clearHistory();
        webView.clearCache(true);

        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();

        connectionStatus.setText("● Desconectado");
        connectionStatus.setTextColor(Color.rgb(136, 148, 139));

        showLoginScreen();
        loginStatus.setText("Sessão encerrada.");
    }

    private void saveCredentials() {
        securePrefs.edit()
                .putString("email", emailInput.getText().toString().trim())
                .putString("password", passwordInput.getText().toString())
                .apply();
    }

    private void loadSavedCredentials() {
        emailInput.setText(securePrefs.getString("email", ""));
        passwordInput.setText(securePrefs.getString("password", ""));
    }

    private void startFlow() {
        if (running) return;

        if (!authenticated) {
            showLoginScreen();
            toast("Faça login primeiro.");
            return;
        }

        String mac = normalizeMac(macInput.getText().toString());
        String playlist = playlistInput.getText().toString().trim();
        String server = serverInput.getText().toString().trim();

        if (!isValidMac(mac)) {
            toast("Informe um MAC válido.");
            return;
        }

        if (!(playlist.startsWith("http://") || playlist.startsWith("https://"))) {
            toast("Informe uma URL M3U válida.");
            return;
        }

        activeFlow = flowSpinner.getSelectedItemPosition() == 1
                ? Flow.EDIT_M3U
                : Flow.ACTIVATE;

        String selectedApp = "";

        if (activeFlow == Flow.ACTIVATE) {
            if (appSpinner.getSelectedItemPosition() <= 0) {
                toast("Selecione o aplicativo do cliente.");
                return;
            }

            selectedApp = String.valueOf(appSpinner.getSelectedItem());

            if (server.isEmpty()) {
                toast("Informe o nome do servidor.");
                return;
            }
        }

        currentMac = mac;
        currentPlaylist = playlist;
        currentServer = server;
        currentApp = selectedApp;

        automationInjected = false;
        searchInjected = false;
        automationRetryCount = 0;
        running = true;

        executeButton.setEnabled(false);
        executeButton.setText("PROCESSANDO...");

        addProgress(
                "INÍCIO",
                activeFlow == Flow.ACTIVATE
                        ? "Ativando MAC..."
                        : "Localizando MAC...",
                Color.rgb(255, 166, 0)
        );

        if (activeFlow == Flow.ACTIVATE) {
            webView.loadUrl(CREATE_USER + "?t=" + System.currentTimeMillis());
        } else {
            webView.loadUrl(USERS + "?t=" + System.currentTimeMillis());
        }
    }

    private String normalizeMac(String value) {
        String clean = value == null
                ? ""
                : value.trim().toUpperCase(Locale.ROOT);

        clean = clean.replace("-", ":");

        String hex = clean.replaceAll("[^A-F0-9]", "");

        if (hex.length() == 12) {
            StringBuilder out = new StringBuilder();

            for (int i = 0; i < 12; i += 2) {
                if (out.length() > 0) out.append(":");
                out.append(hex, i, i + 2);
            }

            return out.toString();
        }

        return clean;
    }

    private boolean isValidMac(String mac) {
        return mac != null
                && mac.matches("^([0-9A-F]{2}:){5}[0-9A-F]{2}$");
    }

    private void handlePageFinished(String url) {
        if (url == null) return;

        String lower = url.toLowerCase(Locale.ROOT);

        if (manualRefreshing) {
            manualRefreshing = false;

            if (refreshLayout != null) {
                refreshLayout.setRefreshing(false);
            }

            // Se a sessão expirou durante o gesto de atualizar, reloga sozinho.
            if (isLoginUrl(lower)) {
                showLoginScreen();
                loginStatus.setText("Sessão expirada. Reconectando...");
                authenticateOnly();
                return;
            }

            if (consoleView.getVisibility() == View.VISIBLE) {
                addProgress(
                        "PRONTO",
                        "Atualizado. Pronto para iniciar.",
                        Color.rgb(136, 148, 139)
                );
            }

            if (!running) return;
        }

        if (!running) return;

        if (loginOnlyMode) {
            if (isAuthenticatedUrl(lower)) {
                showAppScreen();
                return;
            }

            if (isLoginUrl(lower) && !loginInjected) {
                loginInjected = true;

                webView.evaluateJavascript(
                        JsScripts.login(
                                emailInput.getText().toString().trim(),
                                passwordInput.getText().toString()
                        ),
                        null
                );

                loginStatus.setText("Autenticando...");
                return;
            }

            // Em caso de rota intermediária, aguarda um pouco antes do fallback.
            handler.postDelayed(() -> {
                if (!loginOnlyMode || !running) return;

                String current = webView.getUrl();
                String c = current == null ? "" : current.toLowerCase(Locale.ROOT);

                if (isAuthenticatedUrl(c)) {
                    showAppScreen();
                } else if (!loginInjected && loginRetryCount < 2) {
                    loginRetryCount++;
                    webView.loadUrl(BASE + "?t=" + System.currentTimeMillis());
                }
            }, 1800);

            return;
        }

        if (activeFlow == Flow.ACTIVATE) {
            if (lower.contains("/users/create")) {
                if (!automationInjected) {
                    automationInjected = true;

                    webView.evaluateJavascript(
                            JsScripts.activate(
                                    currentMac,
                                    currentApp,
                                    currentServer,
                                    currentPlaylist
                            ),
                            null
                    );
                }
                return;
            }

            if (lower.contains("/users") && !lower.contains("/create")) {
                finishFlow("Ativação concluída.");
            }

            return;
        }

        if (activeFlow == Flow.EDIT_M3U) {
            if (lower.matches(".*\\/users\\/\\d+\\/edit.*")) {
                if (!automationInjected) {
                    automationInjected = true;

                    webView.evaluateJavascript(
                            JsScripts.editM3u(
                                    currentServer,
                                    currentPlaylist
                            ),
                            null
                    );
                }
                return;
            }

            if (lower.contains("/users") && !lower.contains("/create")) {
                if (!searchInjected) {
                    searchInjected = true;

                    webView.evaluateJavascript(
                            JsScripts.findUserAndOpenEdit(currentMac),
                            null
                    );
                } else {
                    // Alguns filtros do painel recarregam a página.
                    // Nesse caso o JavaScript anterior é destruído; resolve novamente
                    // o ID/rota do usuário já filtrado.
                    handler.postDelayed(() -> {
                        if (!running || activeFlow != Flow.EDIT_M3U) return;

                        String current = webView.getUrl();
                        String c = current == null
                                ? ""
                                : current.toLowerCase(Locale.ROOT);

                        if (c.contains("/users")
                                && !c.matches(".*\\/users\\/\\d+\\/edit.*")) {
                            webView.evaluateJavascript(
                                    JsScripts.resolveUserEdit(currentMac),
                                    null
                            );
                        }
                    }, 700);
                }
            }
        }
    }

    private boolean isLoginUrl(String lower) {
        if (lower == null) return false;

        return lower.equals("https://gerenciaapp.top/")
                || lower.startsWith("https://gerenciaapp.top/?")
                || lower.contains("/login")
                || lower.contains("/signin");
    }

    private boolean isAuthenticatedUrl(String lower) {
        if (lower == null) return false;

        return lower.contains("/dashboard")
                || lower.contains("/users")
                || lower.contains("/menu");
    }

    private void onAutomationMessage(String raw) {
        runOnUiThread(() -> {
            try {
                JSONObject obj = new JSONObject(raw);

                String type = obj.optString("type", "progress");
                String code = obj.optString("code", "EVENT");
                String message = obj.optString("message", "");

                if (loginOnlyMode) {
                    if ("LOGIN_OK".equals(code)) {
                        return;
                    }

                    if ("error".equals(type)) {
                        if (loginRetryCount < 2) {
                            loginRetryCount++;
                            loginInjected = false;
                            loginStatus.setText("Tentando novamente...");
                            webView.loadUrl(BASE + "?t=" + System.currentTimeMillis());
                        } else {
                            loginOnlyMode = false;
                            running = false;
                            loginButton.setEnabled(true);
                            loginButton.setText("ENTRAR");
                            loginStatus.setText(message);
                        }
                    } else {
                        loginStatus.setText(message);
                    }

                    return;
                }

                if ("ACTIVATE_SUBMITTED".equals(code)) {
                    finishFlow("Ativação enviada com sucesso.");
                    return;
                }

                if ("EDIT_PAGE_FOUND".equals(code)) {
                    return;
                }

                if ("EDIT_SUBMITTED".equals(code)) {
                    finishFlow("M3U atualizada com sucesso.");
                    return;
                }

                if ("error".equals(type)) {
                    handleAutomationError(code, message);
                    return;
                }

                addProgress(code, message, Color.rgb(255, 166, 0));

            } catch (Exception error) {
                handleAutomationError(
                        "INVALID_MESSAGE",
                        "Resposta inválida do painel."
                );
            }
        });
    }

    private void handleAutomationError(String code, String message) {
        if (isRecoverableAutomationError(code) && automationRetryCount < 3) {
            automationRetryCount++;

            addProgress(
                    "RETRY",
                    "Tentativa automática "
                            + automationRetryCount
                            + "/3...",
                    Color.rgb(255, 166, 0)
            );

            handler.postDelayed(() -> {
                if (!running) return;

                automationInjected = false;
                searchInjected = false;

                if (activeFlow == Flow.ACTIVATE) {
                    webView.loadUrl(
                            CREATE_USER + "?t=" + System.currentTimeMillis()
                    );
                } else {
                    String current = webView.getUrl();

                    if (current != null
                            && current.toLowerCase(Locale.ROOT).matches(
                            ".*\\/users\\/\\d+\\/edit.*"
                    )) {
                        webView.reload();
                    } else {
                        webView.loadUrl(
                                USERS + "?t=" + System.currentTimeMillis()
                        );
                    }
                }
            }, 1000);

            return;
        }

        recordHistory(
                activeFlow,
                currentMac,
                "Falha",
                message
        );

        addProgress(
                "ERRO",
                message,
                Color.rgb(255, 92, 92)
        );

        stopBusyOnly();
    }

    private boolean isRecoverableAutomationError(String code) {
        return "CREATE_FORM_NOT_FOUND".equals(code)
                || "MAC_INPUT_NOT_FOUND".equals(code)
                || "APP_SELECT_NOT_FOUND".equals(code)
                || "PLAYLIST_FORM_NOT_READY".equals(code)
                || "PLAYLIST_INPUT_NOT_FOUND".equals(code)
                || "SEARCH_INPUT_NOT_FOUND".equals(code)
                || "EDIT_LINK_NOT_FOUND".equals(code)
                || "EDIT_FORM_NOT_READY".equals(code);
    }

    private void finishFlow(String message) {
        if (!running) return;

        recordHistory(
                activeFlow,
                currentMac,
                "Sucesso",
                message
        );

        addProgress(
                "CONCLUÍDO",
                message + " Pronto para o próximo dispositivo.",
                Color.rgb(0, 184, 255)
        );

        running = false;
        automationRetryCount = 0;

        macInput.setText("");
        playlistInput.setText("");
        currentMac = "";
        currentPlaylist = "";
        currentServer = "";
        currentApp = "";

        if (activeFlow == Flow.ACTIVATE) {
            serverInput.setText("Meu aplicativo");
            appSpinner.setSelection(0);
        } else {
            serverInput.setText("");
        }

        executeButton.setEnabled(true);
        executeButton.setText("EXECUTAR");

        macInput.requestFocus();
    }

    private void stopBusyOnly() {
        running = false;
        executeButton.setEnabled(true);
        executeButton.setText("EXECUTAR");
    }

    private void addProgress(String code, String message, int color) {
        progressList.removeAllViews();

        TextView line = new TextView(this);
        line.setText("● " + message);
        line.setTextColor(
                "ERRO".equals(code)
                        ? Color.rgb(255, 92, 92)
                        : "CONCLUÍDO".equals(code)
                        ? Color.rgb(0, 184, 255)
                        : color
        );
        line.setTextSize(18);
        line.setTypeface(null, 1);
        line.setPadding(0, dp(18), 0, dp(18));
        line.setGravity(Gravity.CENTER_VERTICAL);

        progressList.addView(line);
    }

    private void togglePanel() {
        boolean opening = webView.getVisibility() != View.VISIBLE;

        if (opening) {
            // REGRA FIXA: PAINEL sempre abre o dashboard principal.
            webView.loadUrl(
                    DASHBOARD + "?t=" + System.currentTimeMillis()
            );
            showPanel(true);
        } else {
            showPanel(false);
        }
    }

    private void showPanel(boolean show) {
        webView.setVisibility(show ? View.VISIBLE : View.GONE);
        consoleView.setVisibility(show ? View.GONE : View.VISIBLE);
        panelButton.setText(show ? "VOLTAR" : "PAINEL");
    }

    private void showSummary() {
        try {
            JSONArray history = new JSONArray(
                    securePrefs.getString("operation_history", "[]")
            );

            Calendar start = Calendar.getInstance();
            start.set(Calendar.HOUR_OF_DAY, 0);
            start.set(Calendar.MINUTE, 0);
            start.set(Calendar.SECOND, 0);
            start.set(Calendar.MILLISECOND, 0);

            int today = 0;
            int success = 0;
            int failed = 0;

            for (int i = 0; i < history.length(); i++) {
                JSONObject item = history.optJSONObject(i);
                if (item == null) continue;

                if (item.optLong("ts", 0L) >= start.getTimeInMillis()) {
                    today++;

                    if ("Sucesso".equals(item.optString("result"))) {
                        success++;
                    } else {
                        failed++;
                    }
                }
            }

            StringBuilder text = new StringBuilder();
            text.append("Sessão: Conectado\n");
            text.append("Versão: ")
                    .append(getInstalledVersionName())
                    .append("\n\n");
            text.append("Hoje\n");
            text.append("• Operações: ").append(today).append("\n");
            text.append("• Sucessos: ").append(success).append("\n");
            text.append("• Falhas: ").append(failed).append("\n\n");
            text.append("Últimas operações\n");

            if (history.length() == 0) {
                text.append("Nenhuma operação registrada.");
            } else {
                SimpleDateFormat format =
                        new SimpleDateFormat(
                                "dd/MM HH:mm",
                                Locale.getDefault()
                        );

                int shown = 0;

                for (int i = history.length() - 1;
                     i >= 0 && shown < 10;
                     i--) {

                    JSONObject item = history.optJSONObject(i);
                    if (item == null) continue;

                    text.append("\n")
                            .append("Sucesso".equals(
                                    item.optString("result")
                            ) ? "✓ " : "! ")
                            .append(format.format(
                                    new Date(item.optLong("ts"))
                            ))
                            .append(" • ")
                            .append(item.optString("device", "-"))
                            .append("\n   ")
                            .append(item.optString("flow", "-"))
                            .append(" • ")
                            .append(item.optString("result", "-"));

                    shown++;
                }
            }

            new AlertDialog.Builder(this)
                    .setTitle("RESUMO • MASTER IBO")
                    .setMessage(text.toString())
                    .setPositiveButton("FECHAR", null)
                    .setNeutralButton(
                            "LIMPAR HISTÓRICO",
                            (dialog, which) -> {
                                securePrefs.edit()
                                        .remove("operation_history")
                                        .apply();
                                toast("Histórico limpo.");
                            }
                    )
                    .show();

        } catch (Exception error) {
            toast("Não foi possível abrir o resumo.");
        }
    }

    private void recordHistory(
            Flow flow,
            String device,
            String result,
            String detail
    ) {
        if (device == null || device.trim().isEmpty()) return;

        try {
            JSONArray current = new JSONArray(
                    securePrefs.getString("operation_history", "[]")
            );

            JSONObject item = new JSONObject();
            item.put("ts", System.currentTimeMillis());
            item.put("device", device);
            item.put("flow", flowLabel(flow));
            item.put("result", result);

            // Nunca salva senha nem URL M3U no histórico.
            if (detail != null && !detail.isEmpty()) {
                item.put("detail", detail);
            }

            current.put(item);

            JSONArray trimmed = new JSONArray();
            int start = Math.max(0, current.length() - 50);

            for (int i = start; i < current.length(); i++) {
                trimmed.put(current.get(i));
            }

            securePrefs.edit()
                    .putString("operation_history", trimmed.toString())
                    .apply();

        } catch (Exception ignored) {
        }
    }

    private String flowLabel(Flow flow) {
        return flow == Flow.EDIT_M3U
                ? "Editar / Repor M3U"
                : "Ativar MAC + M3U";
    }

    private String getInstalledVersionName() {
        try {
            return getPackageManager()
                    .getPackageInfo(getPackageName(), 0)
                    .versionName;
        } catch (Exception error) {
            return "1.0.0";
        }
    }

    private int getDrawableId(String name, String type) {
        return getResources().getIdentifier(
                name,
                type,
                getPackageName()
        );
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private void toast(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE) {
            showPanel(false);
            return;
        }

        super.onBackPressed();
    }

    public class AutomationBridge {
        @JavascriptInterface
        public void postMessage(String message) {
            onAutomationMessage(message);
        }
    }

    private static class JsScripts {

        private static String quote(String value) {
            return JSONObject.quote(value);
        }

        private static String helpers() {
            return ""
                    + "function post(type,code,message){"
                    + "try{AutomationBridge.postMessage(JSON.stringify({type,code,message}));}catch(e){}"
                    + "}"
                    + "function setVal(el,val){"
                    + "if(!el)return;"
                    + "const proto=Object.getPrototypeOf(el);"
                    + "const d=Object.getOwnPropertyDescriptor(proto,'value');"
                    + "if(d&&d.set){d.set.call(el,val);}else{el.value=val;}"
                    + "el.dispatchEvent(new Event('input',{bubbles:true}));"
                    + "el.dispatchEvent(new Event('change',{bubbles:true}));"
                    + "}"
                    + "function clickReal(el){"
                    + "if(!el)return;"
                    + "['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>{"
                    + "try{el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window}));}catch(e){}"
                    + "});"
                    + "}"
                    + "function norm(s){"
                    + "return (s||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase().trim();"
                    + "}"
                    + "function labelText(el){"
                    + "let p=el.parentElement;let n=0;let out='';"
                    + "while(p&&n<4){out+=' '+(p.innerText||'');p=p.parentElement;n++;}"
                    + "return norm(out);"
                    + "}"
                    + "function selectText(sel,text){"
                    + "const target=norm(text);"
                    + "const opt=[...sel.options].find(o=>norm(o.textContent)===target)"
                    + "||[...sel.options].find(o=>norm(o.textContent).includes(target));"
                    + "if(!opt)return false;"
                    + "setVal(sel,opt.value);return true;"
                    + "}";
        }

        static String login(String email, String password) {
            return "(function(){"
                    + "const EMAIL=" + quote(email) + ";"
                    + "const PASSWORD=" + quote(password) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const emailInput=inputs.find(i=>i.type==='email')"
                    + "||inputs.find(i=>/email|e-mail/i.test(norm(i.placeholder)))"
                    + "||inputs.find(i=>/email/i.test(norm(i.name)));"
                    + "const passInput=inputs.find(i=>i.type==='password')"
                    + "||inputs.find(i=>/senha|password/i.test(norm(i.placeholder)));"
                    + "if(!emailInput||!passInput){"
                    + "if(n>=50){clearInterval(timer);post('error','LOGIN_FIELDS_NOT_FOUND','Campos de login não encontrados.');}"
                    + "return;"
                    + "}"
                    + "clearInterval(timer);"
                    + "post('progress','LOGIN_FILL','Autenticando...');"
                    + "setVal(emailInput,EMAIL);"
                    + "setVal(passInput,PASSWORD);"
                    + "const checks=inputs.filter(i=>i.type==='checkbox');"
                    + "const keep=checks.find(c=>labelText(c).includes('manter conectado'))||checks[0];"
                    + "if(keep&&!keep.checked)clickReal(keep);"
                    + "const form=passInput.closest('form')||emailInput.closest('form');"
                    + "const submit=(form&&form.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].find(b=>norm(b.textContent)==='entrar');"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(submit){clickReal(submit);}"
                    + "else if(form){form.submit();}"
                    + "else{post('error','LOGIN_BUTTON_NOT_FOUND','Botão Entrar não encontrado.');return;}"
                    + "post('progress','LOGIN_OK','Login enviado.');"
                    + "},400);"
                    + "})();true;";
        }

        static String activate(
                String mac,
                String appName,
                String serverName,
                String m3u
        ) {
            return "(function(){"
                    + "const MAC=" + quote(mac) + ";"
                    + "const APP=" + quote(appName) + ";"
                    + "const SERVER=" + quote(serverName) + ";"
                    + "const M3U=" + quote(m3u) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const form=document.querySelector('form');"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const selects=[...document.querySelectorAll('select')];"
                    + "if(!form||inputs.length===0){"
                    + "if(n>=50){clearInterval(timer);post('error','CREATE_FORM_NOT_FOUND','Formulário de cadastro não encontrado.');}"
                    + "return;"
                    + "}"
                    + "let macInput=inputs.find(i=>norm(i.placeholder).includes('00:00:00:00:00:00'))"
                    + "||inputs.find(i=>labelText(i).includes('mac do dispositivo'));"
                    + "if(!macInput){clearInterval(timer);post('error','MAC_INPUT_NOT_FOUND','Campo MAC não encontrado.');return;}"
                    + "let appSelect=selects.find(s=>[...s.options].some(o=>norm(o.textContent)===norm(APP)))"
                    + "||selects.find(s=>labelText(s).includes('app que o cliente'));"
                    + "if(!appSelect){"
                    + "if(n>=50){clearInterval(timer);post('error','APP_SELECT_NOT_FOUND','Lista de aplicativos não encontrada.');}"
                    + "return;"
                    + "}"
                    + "setVal(macInput,MAC);"
                    + "if(!selectText(appSelect,APP)){clearInterval(timer);post('error','APP_OPTION_NOT_FOUND','Aplicativo selecionado não existe no painel.');return;}"
                    + "const titleInput=inputs.find(i=>norm(i.placeholder).includes('titulo geral'));"
                    + "if(titleInput&&SERVER)setVal(titleInput,SERVER);"
                    + "const typeSelect=selects.find(s=>[...s.options].some(o=>norm(o.textContent)==='m3u8'));"
                    + "if(typeSelect)selectText(typeSelect,'M3U8');"
                    + "setTimeout(()=>{"
                    + "const all=[...document.querySelectorAll('input')];"
                    + "const server=all.find(i=>norm(i.placeholder).includes('nome do servidor'));"
                    + "const list=all.find(i=>norm(i.placeholder).includes('lista m3u8'))"
                    + "||all.find(i=>norm(i.placeholder).includes('m3u8')&&i!==server);"
                    + "if(!server||!list){post('error','PLAYLIST_FORM_NOT_READY','Campos da playlist M3U8 ainda não estão prontos.');return;}"
                    + "setVal(server,SERVER);"
                    + "setVal(list,M3U);"
                    + "post('progress','PLAYLIST_FILL','Adicionando M3U...');"
                    + "setTimeout(()=>{"
                    + "const forms=[...document.querySelectorAll('form')];"
                    + "const target=list.closest('form')||forms[forms.length-1]||form;"
                    + "if(target&&typeof target.reportValidity==='function'&&!target.reportValidity()){"
                    + "post('error','FORM_INVALID','O painel recusou algum campo obrigatório.');return;"
                    + "}"
                    + "const send=(target&&target.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].reverse().find(b=>norm(b.textContent)==='enviar');"
                    + "if(target&&typeof target.requestSubmit==='function'){target.requestSubmit();}"
                    + "else if(send){clickReal(send);}"
                    + "else{post('error','SUBMIT_NOT_FOUND','Botão Enviar não encontrado.');return;}"
                    + "post('success','ACTIVATE_SUBMITTED','Ativação enviada.');"
                    + "},700);"
                    + "},700);"
                    + "clearInterval(timer);"
                    + "},400);"
                    + "})();true;";
        }

        static String findUserAndOpenEdit(String mac) {
            return "(function(){"
                    + "const MAC=" + quote(mac) + ";"
                    + helpers()
                    + editResolverHelpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const search=inputs.find(i=>norm(i.placeholder).startsWith('buscar'))"
                    + "||inputs.find(i=>labelText(i).includes('lista de usuarios')&&i.type==='text');"
                    + "if(!search){"
                    + "if(n>=40){clearInterval(timer);post('error','SEARCH_INPUT_NOT_FOUND','Busca de usuários não encontrada.');}"
                    + "return;"
                    + "}"
                    + "setVal(search,MAC);"
                    + "const button=[...document.querySelectorAll('button')].find(b=>norm(b.textContent)==='buscar');"
                    + "if(button)clickReal(button);"
                    + "clearInterval(timer);"
                    + "post('progress','SEARCHING_USER','Localizando MAC...');"
                    + "resolveEdit(MAC,30);"
                    + "},400);"
                    + "})();true;";
        }

        static String resolveUserEdit(String mac) {
            return "(function(){"
                    + "const MAC=" + quote(mac) + ";"
                    + helpers()
                    + editResolverHelpers()
                    + "resolveEdit(MAC,30);"
                    + "})();true;";
        }

        private static String editResolverHelpers() {
            return ""
                    + "function absoluteRoute(raw){"
                    + "try{return new URL(raw,location.href).href;}catch(e){return null;}"
                    + "}"
                    + "function userIdFrom(raw){"
                    + "if(!raw)return null;"
                    + "const m=String(raw).match(/\\\\/users\\\\/(\\\\d+)(?:\\\\/edit)?/i);"
                    + "return m?m[1]:null;"
                    + "}"
                    + "function exactMacNodes(mac){"
                    + "const target=norm(mac);"
                    + "return [...document.querySelectorAll('body *')].filter(el=>{"
                    + "const txt=norm(el.textContent);"
                    + "if(!txt.includes(target))return false;"
                    + "return ![...el.children].some(c=>norm(c.textContent).includes(target));"
                    + "});"
                    + "}"
                    + "function inspectScope(scope){"
                    + "if(!scope)return null;"
                    + "const edit=[...scope.querySelectorAll('a[href]')].find(a=>/\\\\/users\\\\/\\\\d+\\\\/edit/i.test(a.getAttribute('href')||''));"
                    + "if(edit)return {route:absoluteRoute(edit.getAttribute('href'))};"
                    + "const candidates=[...scope.querySelectorAll('a[href],form[action],[data-href],[data-url],[data-route],[onclick]')];"
                    + "for(const el of candidates){"
                    + "const values=[el.getAttribute('href'),el.getAttribute('action'),el.getAttribute('data-href'),el.getAttribute('data-url'),el.getAttribute('data-route'),el.getAttribute('onclick')];"
                    + "for(const raw of values){"
                    + "const id=userIdFrom(raw);"
                    + "if(id)return {route:location.origin+'/users/'+id+'/edit'};"
                    + "}"
                    + "}"
                    + "const html=scope.outerHTML||'';"
                    + "const id=userIdFrom(html);"
                    + "if(id)return {route:location.origin+'/users/'+id+'/edit'};"
                    + "const editButton=[...scope.querySelectorAll('button,a')].find(el=>norm(el.textContent)==='editar'||norm(el.textContent).includes('editar usuario'));"
                    + "if(editButton)return {button:editButton};"
                    + "return null;"
                    + "}"
                    + "function locate(mac){"
                    + "const leaves=exactMacNodes(mac);"
                    + "for(const leaf of leaves){"
                    + "if(leaf.matches&&leaf.matches('a[href]')){"
                    + "const id=userIdFrom(leaf.getAttribute('href'));"
                    + "if(id)return {route:location.origin+'/users/'+id+'/edit'};"
                    + "}"
                    + "let p=leaf;"
                    + "for(let depth=0;p&&depth<12;depth++,p=p.parentElement){"
                    + "const found=inspectScope(p);"
                    + "if(found)return found;"
                    + "}"
                    + "}"
                    + "if(leaves.length>0){"
                    + "const ids=new Set();"
                    + "[...document.querySelectorAll('a[href],form[action],[data-href],[data-url],[data-route]')].forEach(el=>{"
                    + "['href','action','data-href','data-url','data-route'].forEach(attr=>{"
                    + "const id=userIdFrom(el.getAttribute(attr));"
                    + "if(id)ids.add(id);"
                    + "});"
                    + "});"
                    + "if(ids.size===1){"
                    + "const id=[...ids][0];"
                    + "return {route:location.origin+'/users/'+id+'/edit'};"
                    + "}"
                    + "}"
                    + "return null;"
                    + "}"
                    + "function resolveEdit(mac,maxWait){"
                    + "let wait=0;"
                    + "let clicked=false;"
                    + "const result=setInterval(()=>{"
                    + "wait++;"
                    + "const found=locate(mac);"
                    + "if(found&&found.route){"
                    + "clearInterval(result);"
                    + "post('progress','EDIT_PAGE_FOUND','Abrindo edição do usuário...');"
                    + "location.href=found.route;"
                    + "return;"
                    + "}"
                    + "if(found&&found.button&&!clicked){"
                    + "clicked=true;"
                    + "clickReal(found.button);"
                    + "post('progress','OPENING_EDIT','Abrindo opções do usuário...');"
                    + "}"
                    + "const now=location.href;"
                    + "if(/\\\\/users\\\\/\\\\d+\\\\/edit/i.test(now)){"
                    + "clearInterval(result);return;"
                    + "}"
                    + "if(wait>=maxWait){"
                    + "clearInterval(result);"
                    + "post('error','EDIT_LINK_NOT_FOUND','Usuário encontrado, mas a edição não ficou disponível.');"
                    + "}"
                    + "},500);"
                    + "}"
                    ;
        }

        static String editM3u(String serverName, String m3u) {
            return "(function(){"
                    + "const SERVER=" + quote(serverName) + ";"
                    + "const M3U=" + quote(m3u) + ";"
                    + helpers()
                    + "let n=0;"
                    + "const timer=setInterval(()=>{"
                    + "n++;"
                    + "const selects=[...document.querySelectorAll('select')];"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "if(selects.length===0||inputs.length===0){"
                    + "if(n>=50){clearInterval(timer);post('error','EDIT_FORM_NOT_READY','Formulário de edição não carregou.');}"
                    + "return;"
                    + "}"
                    + "let typeSelect=selects.find(s=>{"
                    + "const selected=s.options[s.selectedIndex];"
                    + "return selected&&norm(selected.textContent)==='m3u8';"
                    + "});"
                    + "if(!typeSelect){"
                    + "typeSelect=selects.find(s=>[...s.options].some(o=>norm(o.textContent)==='m3u8'));"
                    + "}"
                    + "if(!typeSelect){"
                    + "const add=[...document.querySelectorAll('button')].find(b=>norm(b.textContent).includes('adicionar playlist'));"
                    + "if(add){clickReal(add);return;}"
                    + "if(n>=50){clearInterval(timer);post('error','PLAYLIST_INPUT_NOT_FOUND','Playlist M3U8 não encontrada.');}"
                    + "return;"
                    + "}"
                    + "selectText(typeSelect,'M3U8');"
                    + "let box=typeSelect.parentElement;"
                    + "for(let d=0;box&&d<5;d++){"
                    + "const txt=norm(box.innerText);"
                    + "if(txt.includes('playlist'))break;"
                    + "box=box.parentElement;"
                    + "}"
                    + "box=box||document;"
                    + "setTimeout(()=>{"
                    + "const local=[...box.querySelectorAll('input')];"
                    + "const server=local.find(i=>norm(i.placeholder).includes('nome do servidor'));"
                    + "const list=local.find(i=>norm(i.placeholder).includes('lista m3u8'))"
                    + "||local.find(i=>/^https?:\\/\\//i.test(i.value||''));"
                    + "if(!list){post('error','PLAYLIST_INPUT_NOT_FOUND','Campo da M3U8 não encontrado.');return;}"
                    + "if(server&&SERVER)setVal(server,SERVER);"
                    + "setVal(list,M3U);"
                    + "post('progress','EDITING_M3U','Atualizando M3U...');"
                    + "const form=list.closest('form')||document.querySelector('form');"
                    + "setTimeout(()=>{"
                    + "if(form&&typeof form.reportValidity==='function'&&!form.reportValidity()){"
                    + "post('error','FORM_INVALID','O painel recusou algum campo obrigatório.');return;"
                    + "}"
                    + "const send=(form&&form.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].reverse().find(b=>norm(b.textContent)==='enviar');"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(send){clickReal(send);}"
                    + "else{post('error','SUBMIT_NOT_FOUND','Botão Enviar não encontrado.');return;}"
                    + "post('success','EDIT_SUBMITTED','M3U atualizada.');"
                    + "},700);"
                    + "},500);"
                    + "clearInterval(timer);"
                    + "},400);"
                    + "})();true;";
        }
    }
}
