# MASTER IBO v1.2.3

Base: v1.2.2 assinada.

## Responsividade completa
A interface foi revisada para se adaptar a:
- celulares muito pequenos;
- celulares compactos;
- aparelhos médios;
- telas grandes;
- tablets;
- diferentes densidades e escalas de fonte.

### Elementos adaptativos
- barra superior;
- botões PAINEL / INFO ou RESUMO / SAIR;
- login rolável;
- logo e títulos;
- campos de e-mail e senha;
- formulário principal;
- cards;
- spinners;
- campos MAC / servidor / M3U;
- botão EXECUTAR;
- status;
- WebView;
- diálogo de RESUMO com largura e conteúdo rolável adaptativos.

### Teclado
A Activity usa adjustResize para que o teclado não cubra campos e botões.

### Assinatura
Mantém a mesma assinatura permanente configurada na v1.2.2.

Versão: 1.2.3
versionCode: 5
